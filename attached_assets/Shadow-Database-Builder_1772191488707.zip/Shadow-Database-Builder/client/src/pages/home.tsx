import { useQuery } from "@tanstack/react-query";
import { useState, useMemo, useRef } from "react";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import {
  Search,
  BookOpen,
  Database,
  Users,
  Sparkles,
  ChevronRight,
  Globe,
  Skull,
  Heart,
  Shield,
  Flame,
  Moon,
  Sun,
  Swords,
  TreePine,
  Download,
  Upload,
  Layers,
  Tag,
} from "lucide-react";

interface Entry {
  name: string;
  tradition: string;
  gender: string;
  domain: string;
  object: string | null;
  animals: string | null;
  characterTrait: string | null;
  physicalCharacteristics: string | null;
  significantEvent: string | null;
  symbolism: string | null;
  neumannArchetype: string | null;
  mentionCount: number;
  inDatabase: boolean;
  source: "text" | "database" | "both";
  birthCircumstances?: string | null;
  deathCircumstances?: string | null;
  eventTypes?: string[];
  birthTypes?: string[];
  deathTypes?: string[];
  familyRoles?: string[];
}

interface Stats {
  totalDatabaseNodes: number;
  totalEdges: number;
  totalCatalogEntries: number;
  inDatabase: number;
  newFromText: number;
  databaseTraditions: string[];
  catalogTraditions: string[];
}

const EVENT_TYPE_LABELS: Record<string, string> = {
  slays_monster: "Slays Monster",
  slays_kin: "Slays Kin",
  overthrows_ruler: "Overthrows Ruler",
  vengeance: "Vengeance",
  contest: "Contest",
  curse: "Curse",
  punishment: "Punishment",
  loss_of_power: "Loss of Power",
  apotheosis: "Apotheosis",
  descent_to_underworld: "Descent to Underworld",
  quest: "Quest",
  exile: "Exile",
  abduction: "Abduction",
  world_creation: "World Creation",
  humanity_creation: "Humanity Creation",
  gift_to_humanity: "Gift to Humanity",
  founding: "Founding",
  invention: "Invention",
  divine_marriage: "Divine Marriage",
  seduction: "Seduction",
  betrayal: "Betrayal",
  rescue: "Rescue",
  sacrifice: "Sacrifice",
};

const EVENT_TYPE_COLORS: Record<string, string> = {
  slays_monster: "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300",
  slays_kin: "bg-red-200 text-red-900 dark:bg-red-900/40 dark:text-red-200",
  overthrows_ruler: "bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-300",
  vengeance: "bg-rose-100 text-rose-800 dark:bg-rose-900/30 dark:text-rose-300",
  contest: "bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-300",
  curse: "bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-300",
  punishment: "bg-violet-100 text-violet-800 dark:bg-violet-900/30 dark:text-violet-300",
  loss_of_power: "bg-gray-100 text-gray-800 dark:bg-gray-900/30 dark:text-gray-300",
  apotheosis: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-300",
  descent_to_underworld: "bg-slate-200 text-slate-800 dark:bg-slate-800/40 dark:text-slate-300",
  quest: "bg-sky-100 text-sky-800 dark:bg-sky-900/30 dark:text-sky-300",
  exile: "bg-stone-100 text-stone-800 dark:bg-stone-900/30 dark:text-stone-300",
  abduction: "bg-fuchsia-100 text-fuchsia-800 dark:bg-fuchsia-900/30 dark:text-fuchsia-300",
  world_creation: "bg-emerald-100 text-emerald-800 dark:bg-emerald-900/30 dark:text-emerald-300",
  humanity_creation: "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300",
  gift_to_humanity: "bg-teal-100 text-teal-800 dark:bg-teal-900/30 dark:text-teal-300",
  founding: "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300",
  invention: "bg-cyan-100 text-cyan-800 dark:bg-cyan-900/30 dark:text-cyan-300",
  divine_marriage: "bg-pink-100 text-pink-800 dark:bg-pink-900/30 dark:text-pink-300",
  seduction: "bg-pink-200 text-pink-900 dark:bg-pink-900/40 dark:text-pink-200",
  betrayal: "bg-zinc-200 text-zinc-800 dark:bg-zinc-800/40 dark:text-zinc-300",
  rescue: "bg-lime-100 text-lime-800 dark:bg-lime-900/30 dark:text-lime-300",
  sacrifice: "bg-indigo-100 text-indigo-800 dark:bg-indigo-900/30 dark:text-indigo-300",
};

const BIRTH_TYPE_LABELS: Record<string, string> = {
  divine_parentage: "Divine Parentage",
  demigod_birth: "Demigod Birth",
  mortal_parentage: "Mortal Parentage",
  parthenogenesis: "Parthenogenesis",
  primordial_emergence: "Primordial Emergence",
  born_from_body: "Born from Body",
  born_from_element: "Born from Element",
  miraculous_conception: "Miraculous Conception",
  incestuous_union: "Incestuous Union",
  abandoned_at_birth: "Abandoned at Birth",
  royal_lineage: "Royal Lineage",
  prophesied_birth: "Prophesied Birth",
};

const BIRTH_TYPE_COLORS: Record<string, string> = {
  divine_parentage: "bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-300",
  demigod_birth: "bg-sky-100 text-sky-800 dark:bg-sky-900/30 dark:text-sky-300",
  mortal_parentage: "bg-stone-100 text-stone-800 dark:bg-stone-900/30 dark:text-stone-300",
  parthenogenesis: "bg-violet-100 text-violet-800 dark:bg-violet-900/30 dark:text-violet-300",
  primordial_emergence: "bg-emerald-100 text-emerald-800 dark:bg-emerald-900/30 dark:text-emerald-300",
  born_from_body: "bg-rose-100 text-rose-800 dark:bg-rose-900/30 dark:text-rose-300",
  born_from_element: "bg-teal-100 text-teal-800 dark:bg-teal-900/30 dark:text-teal-300",
  miraculous_conception: "bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-300",
  incestuous_union: "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300",
  abandoned_at_birth: "bg-gray-200 text-gray-800 dark:bg-gray-800/40 dark:text-gray-300",
  royal_lineage: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-300",
  prophesied_birth: "bg-indigo-100 text-indigo-800 dark:bg-indigo-900/30 dark:text-indigo-300",
};

const DEATH_TYPE_LABELS: Record<string, string> = {
  killed_in_battle: "Killed in Battle",
  killed_by_god: "Killed by God",
  killed_by_hero: "Killed by Hero",
  killed_by_kin: "Killed by Kin",
  self_sacrifice: "Self-Sacrifice",
  suicide: "Suicide",
  dismemberment: "Dismemberment",
  transformation_at_death: "Transformation at Death",
  immortality_denied: "Immortality Denied",
  sacrificed_ritually: "Sacrificed Ritually",
  betrayed_and_killed: "Betrayed & Killed",
  natural_death: "Natural Death",
  eternal_punishment: "Eternal Punishment",
  resurrection: "Resurrection",
  prophesied_death: "Prophesied Death",
};

const DEATH_TYPE_COLORS: Record<string, string> = {
  killed_in_battle: "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300",
  killed_by_god: "bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-300",
  killed_by_hero: "bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-300",
  killed_by_kin: "bg-rose-200 text-rose-900 dark:bg-rose-900/40 dark:text-rose-200",
  self_sacrifice: "bg-indigo-100 text-indigo-800 dark:bg-indigo-900/30 dark:text-indigo-300",
  suicide: "bg-slate-200 text-slate-800 dark:bg-slate-800/40 dark:text-slate-300",
  dismemberment: "bg-red-200 text-red-900 dark:bg-red-900/40 dark:text-red-200",
  transformation_at_death: "bg-violet-100 text-violet-800 dark:bg-violet-900/30 dark:text-violet-300",
  immortality_denied: "bg-gray-200 text-gray-800 dark:bg-gray-800/40 dark:text-gray-300",
  sacrificed_ritually: "bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-300",
  betrayed_and_killed: "bg-zinc-200 text-zinc-800 dark:bg-zinc-800/40 dark:text-zinc-300",
  natural_death: "bg-stone-100 text-stone-800 dark:bg-stone-900/30 dark:text-stone-300",
  eternal_punishment: "bg-fuchsia-100 text-fuchsia-800 dark:bg-fuchsia-900/30 dark:text-fuchsia-300",
  resurrection: "bg-emerald-100 text-emerald-800 dark:bg-emerald-900/30 dark:text-emerald-300",
  prophesied_death: "bg-sky-100 text-sky-800 dark:bg-sky-900/30 dark:text-sky-300",
};

const FAMILY_ROLE_LABELS: Record<string, string> = {
  mother: "Mother",
  father: "Father",
  sister: "Sister",
  brother: "Brother",
};

const FAMILY_ROLE_COLORS: Record<string, string> = {
  mother: "bg-pink-100 text-pink-800 dark:bg-pink-900/30 dark:text-pink-300",
  father: "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300",
  sister: "bg-rose-100 text-rose-800 dark:bg-rose-900/30 dark:text-rose-300",
  brother: "bg-cyan-100 text-cyan-800 dark:bg-cyan-900/30 dark:text-cyan-300",
};

function getTraditionIcon(tradition: string) {
  const t = (tradition || "").toLowerCase();
  if (t.includes("egyptian")) return <Sun className="w-4 h-4" />;
  if (t.includes("greek") || t.includes("hellenic")) return <Shield className="w-4 h-4" />;
  if (t.includes("norse") || t.includes("germanic")) return <Swords className="w-4 h-4" />;
  if (t.includes("hindu") || t.includes("indian") || t.includes("buddhist") || t.includes("tibetan"))
    return <Flame className="w-4 h-4" />;
  if (t.includes("aztec") || t.includes("mexican")) return <Skull className="w-4 h-4" />;
  if (t.includes("babylonian") || t.includes("mesopotamian") || t.includes("sumerian"))
    return <Moon className="w-4 h-4" />;
  if (t.includes("christian") || t.includes("jewish") || t.includes("gnostic"))
    return <Heart className="w-4 h-4" />;
  if (t.includes("celtic") || t.includes("cretan")) return <TreePine className="w-4 h-4" />;
  if (t.includes("shinto")) return <Flame className="w-4 h-4" />;
  if (t.includes("roman")) return <Shield className="w-4 h-4" />;
  return <Globe className="w-4 h-4" />;
}

function getTraditionColor(tradition: string) {
  const t = (tradition || "").toLowerCase();
  if (t.includes("egyptian")) return "bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-300";
  if (t.includes("greek") || t.includes("hellenic")) return "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300";
  if (t.includes("norse") || t.includes("germanic")) return "bg-slate-100 text-slate-800 dark:bg-slate-900/30 dark:text-slate-300";
  if (t.includes("hindu") || t.includes("indian")) return "bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-300";
  if (t.includes("buddhist") || t.includes("tibetan")) return "bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-300";
  if (t.includes("aztec") || t.includes("mexican")) return "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300";
  if (t.includes("babylonian") || t.includes("mesopotamian") || t.includes("sumerian"))
    return "bg-teal-100 text-teal-800 dark:bg-teal-900/30 dark:text-teal-300";
  if (t.includes("christian") || t.includes("jewish") || t.includes("gnostic"))
    return "bg-rose-100 text-rose-800 dark:bg-rose-900/30 dark:text-rose-300";
  if (t.includes("roman")) return "bg-indigo-100 text-indigo-800 dark:bg-indigo-900/30 dark:text-indigo-300";
  if (t.includes("phrygian") || t.includes("anatolian")) return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-300";
  if (t.includes("phoenician") || t.includes("canaanite")) return "bg-emerald-100 text-emerald-800 dark:bg-emerald-900/30 dark:text-emerald-300";
  if (t.includes("balinese")) return "bg-lime-100 text-lime-800 dark:bg-lime-900/30 dark:text-lime-300";
  if (t.includes("celtic")) return "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300";
  if (t.includes("cretan")) return "bg-cyan-100 text-cyan-800 dark:bg-cyan-900/30 dark:text-cyan-300";
  if (t.includes("shinto")) return "bg-pink-100 text-pink-800 dark:bg-pink-900/30 dark:text-pink-300";
  if (t.includes("chinese")) return "bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-300";
  return "bg-gray-100 text-gray-800 dark:bg-gray-900/30 dark:text-gray-300";
}

function getSourceBadge(source: string) {
  if (source === "both") {
    return (
      <Badge variant="default" className="text-xs" data-testid="badge-both">
        <Layers className="w-3 h-3 mr-1" />
        Both
      </Badge>
    );
  }
  if (source === "text") {
    return (
      <Badge variant="outline" className="text-xs border-amber-300 text-amber-700 dark:text-amber-400" data-testid="badge-text">
        <BookOpen className="w-3 h-3 mr-1" />
        Text
      </Badge>
    );
  }
  return (
    <Badge variant="outline" className="text-xs" data-testid="badge-db">
      <Database className="w-3 h-3 mr-1" />
      DB
    </Badge>
  );
}

function TypeBadges({ types, labels, colors, prefix }: { types: string[]; labels: Record<string, string>; colors: Record<string, string>; prefix: string }) {
  if (!types || types.length === 0) return null;
  return (
    <div className="flex flex-wrap gap-1">
      {types.map((t) => (
        <span
          key={t}
          className={`inline-flex items-center text-[10px] px-1.5 py-0.5 rounded ${colors[t] || "bg-gray-100 text-gray-700"}`}
          data-testid={`${prefix}-${t}`}
        >
          {labels[t] || t}
        </span>
      ))}
    </div>
  );
}

function EventTypeBadges({ types }: { types: string[] }) {
  return <TypeBadges types={types} labels={EVENT_TYPE_LABELS} colors={EVENT_TYPE_COLORS} prefix="event-type" />;
}

function BirthTypeBadges({ types }: { types: string[] }) {
  return <TypeBadges types={types} labels={BIRTH_TYPE_LABELS} colors={BIRTH_TYPE_COLORS} prefix="birth-type" />;
}

function DeathTypeBadges({ types }: { types: string[] }) {
  return <TypeBadges types={types} labels={DEATH_TYPE_LABELS} colors={DEATH_TYPE_COLORS} prefix="death-type" />;
}

function FamilyRoleBadges({ roles }: { roles: string[] }) {
  return <TypeBadges types={roles} labels={FAMILY_ROLE_LABELS} colors={FAMILY_ROLE_COLORS} prefix="family-role" />;
}

function StatsCards({ stats, totalShown }: { stats: Stats; totalShown: number }) {
  return (
    <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
      <Card>
        <CardContent className="p-4">
          <div className="flex items-center gap-2 mb-1">
            <Users className="w-4 h-4 text-primary" />
            <span className="text-xs text-muted-foreground">Total Entries</span>
          </div>
          <p className="text-2xl font-bold" data-testid="stat-total">{totalShown}</p>
          <p className="text-xs text-muted-foreground">combined catalog</p>
        </CardContent>
      </Card>
      <Card>
        <CardContent className="p-4">
          <div className="flex items-center gap-2 mb-1">
            <Database className="w-4 h-4 text-primary" />
            <span className="text-xs text-muted-foreground">Database</span>
          </div>
          <p className="text-2xl font-bold" data-testid="stat-db-total">{stats.totalDatabaseNodes}</p>
          <p className="text-xs text-muted-foreground">shadows-database nodes</p>
        </CardContent>
      </Card>
      <Card>
        <CardContent className="p-4">
          <div className="flex items-center gap-2 mb-1">
            <BookOpen className="w-4 h-4 text-primary" />
            <span className="text-xs text-muted-foreground">From Text</span>
          </div>
          <p className="text-2xl font-bold" data-testid="stat-extracted">{stats.totalCatalogEntries}</p>
          <p className="text-xs text-muted-foreground">from "The Great Mother"</p>
        </CardContent>
      </Card>
      <Card>
        <CardContent className="p-4">
          <div className="flex items-center gap-2 mb-1">
            <Layers className="w-4 h-4 text-primary" />
            <span className="text-xs text-muted-foreground">Overlap</span>
          </div>
          <p className="text-2xl font-bold" data-testid="stat-overlap">{stats.inDatabase}</p>
          <p className="text-xs text-muted-foreground">in both sources</p>
        </CardContent>
      </Card>
      <Card>
        <CardContent className="p-4">
          <div className="flex items-center gap-2 mb-1">
            <Sparkles className="w-4 h-4 text-primary" />
            <span className="text-xs text-muted-foreground">New from Text</span>
          </div>
          <p className="text-2xl font-bold" data-testid="stat-new">{stats.newFromText}</p>
          <p className="text-xs text-muted-foreground">not yet in database</p>
        </CardContent>
      </Card>
    </div>
  );
}

function EntryCard({ entry, onClick }: { entry: Entry; onClick: () => void }) {
  const eventTypes = entry.eventTypes || [];
  const birthTypes = entry.birthTypes || [];
  return (
    <Card
      className="cursor-pointer transition-all hover-elevate"
      onClick={onClick}
      data-testid={`card-entry-${entry.name.replace(/\s+/g, "-").toLowerCase()}`}
    >
      <CardContent className="p-4">
        <div className="flex items-start justify-between mb-2">
          <div className="flex items-center gap-2 min-w-0">
            {getTraditionIcon(entry.tradition)}
            <h3 className="font-semibold text-base truncate">{entry.name}</h3>
          </div>
          <div className="flex-shrink-0 ml-2">
            {getSourceBadge(entry.source)}
          </div>
        </div>
        <div className="mb-2 flex items-center gap-2 flex-wrap">
          <span className={`inline-flex items-center gap-1 text-xs px-2 py-0.5 rounded-full ${getTraditionColor(entry.tradition)}`}>
            {entry.tradition}
          </span>
          <span className="text-xs text-muted-foreground">{entry.gender}</span>
        </div>
        {entry.domain && (
          <p className="text-sm text-muted-foreground line-clamp-2 mb-2">{entry.domain}</p>
        )}
        {eventTypes.length > 0 && (
          <div className="mb-1">
            <EventTypeBadges types={eventTypes} />
          </div>
        )}
        {birthTypes.length > 0 && (
          <div className="mb-1">
            <BirthTypeBadges types={birthTypes} />
          </div>
        )}
        {(entry.deathTypes || []).length > 0 && (
          <div className="mb-1">
            <DeathTypeBadges types={entry.deathTypes!} />
          </div>
        )}
        {(entry.familyRoles || []).length > 0 && (
          <div className="mb-2">
            <FamilyRoleBadges roles={entry.familyRoles!} />
          </div>
        )}
        <div className="flex items-center justify-between">
          {entry.mentionCount > 0 ? (
            <span className="text-xs text-muted-foreground">{entry.mentionCount} mentions in text</span>
          ) : (
            <span className="text-xs text-muted-foreground">Database entry</span>
          )}
          <ChevronRight className="w-4 h-4 text-muted-foreground" />
        </div>
      </CardContent>
    </Card>
  );
}

function EntryDetail({ entry, onClose }: { entry: Entry; onClose: () => void }) {
  const fields = [
    { label: "Tradition", value: entry.tradition },
    { label: "Gender", value: entry.gender },
    { label: "Domain", value: entry.domain },
    { label: "Objects/Symbols", value: entry.object },
    { label: "Associated Animals", value: entry.animals },
    { label: "Character Traits", value: entry.characterTrait },
    { label: "Physical Characteristics", value: entry.physicalCharacteristics },
    { label: "Significant Events", value: entry.significantEvent },
    { label: "Symbolism (Neumann)", value: entry.symbolism },
    { label: "Archetypal Role", value: entry.neumannArchetype },
    { label: "Birth Circumstances", value: entry.birthCircumstances },
    { label: "Death Circumstances", value: entry.deathCircumstances },
  ];

  const eventTypes = entry.eventTypes || [];
  const birthTypes = entry.birthTypes || [];

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto" data-testid="dialog-entry-detail">
        <DialogHeader>
          <div className="flex items-center gap-3 flex-wrap">
            {getTraditionIcon(entry.tradition)}
            <DialogTitle className="text-xl">{entry.name}</DialogTitle>
            <span className={`inline-flex items-center gap-1 text-xs px-2 py-0.5 rounded-full ${getTraditionColor(entry.tradition)}`}>
              {entry.tradition}
            </span>
            {getSourceBadge(entry.source)}
          </div>
        </DialogHeader>

        <div className="space-y-4 mt-4">
          <div className="flex items-center gap-4 text-sm text-muted-foreground">
            {entry.mentionCount > 0 && <span>{entry.mentionCount} mentions in text</span>}
            <span>{entry.gender}</span>
            <span className="capitalize">Source: {entry.source === "both" ? "Text + Database" : entry.source === "text" ? "Great Mother text" : "Shadows database"}</span>
          </div>

          {eventTypes.length > 0 && (
            <div>
              <h4 className="text-sm font-medium mb-2 text-foreground flex items-center gap-1">
                <Tag className="w-3.5 h-3.5" />
                Event Types
              </h4>
              <EventTypeBadges types={eventTypes} />
            </div>
          )}

          {birthTypes.length > 0 && (
            <div>
              <h4 className="text-sm font-medium mb-2 text-foreground">Birth Types</h4>
              <BirthTypeBadges types={birthTypes} />
            </div>
          )}

          {(entry.deathTypes || []).length > 0 && (
            <div>
              <h4 className="text-sm font-medium mb-2 text-foreground flex items-center gap-1">
                <Skull className="w-3.5 h-3.5" />
                Death Types
              </h4>
              <DeathTypeBadges types={entry.deathTypes!} />
            </div>
          )}

          {(entry.familyRoles || []).length > 0 && (
            <div>
              <h4 className="text-sm font-medium mb-2 text-foreground flex items-center gap-1">
                <Heart className="w-3.5 h-3.5" />
                Family Roles
              </h4>
              <FamilyRoleBadges roles={entry.familyRoles!} />
            </div>
          )}

          {fields.map(
            (field) =>
              field.value && (
                <div key={field.label}>
                  <h4 className="text-sm font-medium mb-1 text-foreground">{field.label}</h4>
                  <p className="text-sm text-muted-foreground leading-relaxed">{field.value}</p>
                </div>
              )
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}

function LoadingSkeleton() {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        {[1, 2, 3, 4, 5].map((i) => (
          <Card key={i}>
            <CardContent className="p-4">
              <Skeleton className="h-4 w-20 mb-2" />
              <Skeleton className="h-8 w-12 mb-1" />
              <Skeleton className="h-3 w-32" />
            </CardContent>
          </Card>
        ))}
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
        {[1, 2, 3, 4, 5, 6].map((i) => (
          <Card key={i}>
            <CardContent className="p-4">
              <Skeleton className="h-5 w-32 mb-3" />
              <Skeleton className="h-4 w-20 mb-2" />
              <Skeleton className="h-4 w-full mb-1" />
              <Skeleton className="h-4 w-3/4" />
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}

export default function Home() {
  const [search, setSearch] = useState("");
  const [traditionFilter, setTraditionFilter] = useState("all");
  const [sourceFilter, setSourceFilter] = useState("all");
  const [eventTypeFilter, setEventTypeFilter] = useState("all");
  const [birthTypeFilter, setBirthTypeFilter] = useState("all");
  const [deathTypeFilter, setDeathTypeFilter] = useState("all");
  const [familyRoleFilter, setFamilyRoleFilter] = useState("all");
  const [sortBy, setSortBy] = useState("name");
  const [selectedEntry, setSelectedEntry] = useState<Entry | null>(null);
  const [importing, setImporting] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  function handleImportClick() {
    fileInputRef.current?.click();
  }

  async function handleFileSelected(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;

    setImporting(true);
    try {
      const text = await file.text();
      const data = JSON.parse(text);
      const res = await apiRequest("POST", "/api/database/import", data);
      const result = await res.json();

      toast({
        title: "Database imported",
        description: `${result.totalNodes} nodes loaded. ${result.catalogMatches} catalog matches, ${result.newEntries} new entries.`,
      });

      queryClient.invalidateQueries({ queryKey: ["/api/all-entries"] });
      queryClient.invalidateQueries({ queryKey: ["/api/database/stats"] });
    } catch (err: any) {
      toast({
        title: "Import failed",
        description: err.message || "Could not parse or import the file.",
        variant: "destructive",
      });
    } finally {
      setImporting(false);
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  }

  const { data: entries, isLoading: entriesLoading } = useQuery<Entry[]>({
    queryKey: ["/api/all-entries"],
  });

  const { data: stats, isLoading: statsLoading } = useQuery<Stats>({
    queryKey: ["/api/database/stats"],
  });

  const traditions = useMemo(() => {
    if (!entries) return [];
    return [...new Set(entries.map((d) => d.tradition).filter(Boolean))].sort();
  }, [entries]);

  const availableEventTypes = useMemo(() => {
    if (!entries) return [];
    const types = new Set<string>();
    for (const e of entries) {
      for (const t of (e.eventTypes || [])) {
        types.add(t);
      }
    }
    return [...types].sort((a, b) => (EVENT_TYPE_LABELS[a] || a).localeCompare(EVENT_TYPE_LABELS[b] || b));
  }, [entries]);

  const availableBirthTypes = useMemo(() => {
    if (!entries) return [];
    const types = new Set<string>();
    for (const e of entries) {
      for (const t of (e.birthTypes || [])) {
        types.add(t);
      }
    }
    return [...types].sort((a, b) => (BIRTH_TYPE_LABELS[a] || a).localeCompare(BIRTH_TYPE_LABELS[b] || b));
  }, [entries]);

  const availableDeathTypes = useMemo(() => {
    if (!entries) return [];
    const types = new Set<string>();
    for (const e of entries) {
      for (const t of (e.deathTypes || [])) {
        types.add(t);
      }
    }
    return [...types].sort((a, b) => (DEATH_TYPE_LABELS[a] || a).localeCompare(DEATH_TYPE_LABELS[b] || b));
  }, [entries]);

  const availableFamilyRoles = useMemo(() => {
    if (!entries) return [];
    const roles = new Set<string>();
    for (const e of entries) {
      for (const r of (e.familyRoles || [])) {
        roles.add(r);
      }
    }
    return [...roles].sort((a, b) => (FAMILY_ROLE_LABELS[a] || a).localeCompare(FAMILY_ROLE_LABELS[b] || b));
  }, [entries]);

  const filtered = useMemo(() => {
    if (!entries) return [];
    let result = entries;

    if (search) {
      const q = search.toLowerCase();
      result = result.filter(
        (d) =>
          d.name.toLowerCase().includes(q) ||
          (d.domain && d.domain.toLowerCase().includes(q)) ||
          (d.tradition && d.tradition.toLowerCase().includes(q)) ||
          (d.symbolism && d.symbolism.toLowerCase().includes(q)) ||
          (d.animals && d.animals.toLowerCase().includes(q)) ||
          (d.object && d.object.toLowerCase().includes(q)) ||
          (d.characterTrait && d.characterTrait.toLowerCase().includes(q))
      );
    }

    if (traditionFilter !== "all") {
      result = result.filter((d) => d.tradition === traditionFilter);
    }

    if (sourceFilter === "text") {
      result = result.filter((d) => d.source === "text");
    } else if (sourceFilter === "database") {
      result = result.filter((d) => d.source === "database");
    } else if (sourceFilter === "both") {
      result = result.filter((d) => d.source === "both");
    }

    if (eventTypeFilter !== "all") {
      result = result.filter((d) => d.eventTypes && d.eventTypes.includes(eventTypeFilter));
    }

    if (birthTypeFilter !== "all") {
      result = result.filter((d) => d.birthTypes && d.birthTypes.includes(birthTypeFilter));
    }

    if (deathTypeFilter !== "all") {
      result = result.filter((d) => d.deathTypes && d.deathTypes.includes(deathTypeFilter));
    }

    if (familyRoleFilter !== "all") {
      result = result.filter((d) => d.familyRoles && d.familyRoles.includes(familyRoleFilter));
    }

    if (sortBy === "mentions") {
      result = [...result].sort((a, b) => b.mentionCount - a.mentionCount);
    } else if (sortBy === "name") {
      result = [...result].sort((a, b) => a.name.localeCompare(b.name));
    } else if (sortBy === "tradition") {
      result = [...result].sort((a, b) => (a.tradition || "").localeCompare(b.tradition || "") || a.name.localeCompare(b.name));
    }

    return result;
  }, [entries, search, traditionFilter, sourceFilter, eventTypeFilter, birthTypeFilter, deathTypeFilter, familyRoleFilter, sortBy]);

  if (entriesLoading || statsLoading) {
    return (
      <div className="min-h-screen bg-background">
        <div className="max-w-6xl mx-auto p-6">
          <Skeleton className="h-10 w-80 mb-2" />
          <Skeleton className="h-5 w-96 mb-6" />
          <LoadingSkeleton />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-6xl mx-auto p-6">
        <header className="mb-6">
          <h1 className="text-2xl font-bold text-foreground mb-1" data-testid="text-page-title">
            Mythology Catalog
          </h1>
          <p className="text-sm text-muted-foreground">
            All deities and mythological figures from the shadows-database and Erich Neumann's "The Great Mother"
          </p>
        </header>

        <div className="flex justify-end gap-2 mb-4">
          <input
            type="file"
            ref={fileInputRef}
            accept=".json"
            onChange={handleFileSelected}
            className="hidden"
            data-testid="input-file-import"
          />
          <Button
            variant="outline"
            onClick={handleImportClick}
            disabled={importing}
            data-testid="button-import-db"
          >
            <Upload className="w-4 h-4 mr-2" />
            {importing ? "Importing..." : "Import New Database"}
          </Button>
          <Button
            variant="outline"
            onClick={() => {
              window.open("/api/download-database", "_blank");
            }}
            data-testid="button-download-database"
          >
            <Download className="w-4 h-4 mr-2" />
            Download Database
          </Button>
        </div>

        {stats && <StatsCards stats={stats} totalShown={entries?.length || 0} />}

        <div className="flex flex-col sm:flex-row gap-3 mt-6 mb-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Search names, domains, traits, symbols..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-9"
              data-testid="input-search"
            />
          </div>
          <Select value={traditionFilter} onValueChange={setTraditionFilter}>
            <SelectTrigger className="w-full sm:w-48" data-testid="select-tradition">
              <SelectValue placeholder="Tradition" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Traditions</SelectItem>
              {traditions.map((t) => (
                <SelectItem key={t} value={t}>{t}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={sourceFilter} onValueChange={setSourceFilter}>
            <SelectTrigger className="w-full sm:w-44" data-testid="select-source">
              <SelectValue placeholder="Source" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Sources</SelectItem>
              <SelectItem value="text">Text Only (New)</SelectItem>
              <SelectItem value="database">Database Only</SelectItem>
              <SelectItem value="both">In Both</SelectItem>
            </SelectContent>
          </Select>
          <Select value={eventTypeFilter} onValueChange={setEventTypeFilter}>
            <SelectTrigger className="w-full sm:w-52" data-testid="select-event-type">
              <SelectValue placeholder="Event Type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Event Types</SelectItem>
              {availableEventTypes.map((t) => (
                <SelectItem key={t} value={t}>{EVENT_TYPE_LABELS[t] || t}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={birthTypeFilter} onValueChange={setBirthTypeFilter}>
            <SelectTrigger className="w-full sm:w-52" data-testid="select-birth-type">
              <SelectValue placeholder="Birth Type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Birth Types</SelectItem>
              {availableBirthTypes.map((t) => (
                <SelectItem key={t} value={t}>{BIRTH_TYPE_LABELS[t] || t}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={deathTypeFilter} onValueChange={setDeathTypeFilter}>
            <SelectTrigger className="w-full sm:w-52" data-testid="select-death-type">
              <SelectValue placeholder="Death Type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Death Types</SelectItem>
              {availableDeathTypes.map((t) => (
                <SelectItem key={t} value={t}>{DEATH_TYPE_LABELS[t] || t}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={familyRoleFilter} onValueChange={setFamilyRoleFilter}>
            <SelectTrigger className="w-full sm:w-44" data-testid="select-family-role">
              <SelectValue placeholder="Family Role" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Family Roles</SelectItem>
              {availableFamilyRoles.map((r) => (
                <SelectItem key={r} value={r}>{FAMILY_ROLE_LABELS[r] || r}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={sortBy} onValueChange={setSortBy}>
            <SelectTrigger className="w-full sm:w-40" data-testid="select-sort">
              <SelectValue placeholder="Sort by" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="name">Name (A-Z)</SelectItem>
              <SelectItem value="mentions">Most Mentions</SelectItem>
              <SelectItem value="tradition">Tradition</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <p className="text-xs text-muted-foreground mb-3" data-testid="text-result-count">
          Showing {filtered.length} of {entries?.length || 0} entries
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {filtered.map((entry, idx) => (
            <EntryCard
              key={`${entry.name}-${entry.source}-${idx}`}
              entry={entry}
              onClick={() => setSelectedEntry(entry)}
            />
          ))}
        </div>

        {filtered.length === 0 && (
          <div className="text-center py-12">
            <p className="text-muted-foreground">No entries match your search criteria.</p>
          </div>
        )}

        {selectedEntry && (
          <EntryDetail entry={selectedEntry} onClose={() => setSelectedEntry(null)} />
        )}
      </div>
    </div>
  );
}
