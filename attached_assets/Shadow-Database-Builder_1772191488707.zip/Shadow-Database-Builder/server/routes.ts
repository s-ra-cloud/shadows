import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import fs from "fs";
import path from "path";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  const catalogPath = path.join(import.meta.dirname, "data", "deity-catalog.json");
  const dbPath = path.join(process.cwd(), "attached_assets", "shadows-database_1772036446426.json");

  app.get("/api/deities", (_req, res) => {
    try {
      const catalog = JSON.parse(fs.readFileSync(catalogPath, "utf8"));
      res.json(catalog);
    } catch (err) {
      res.status(500).json({ error: "Failed to load deity catalog" });
    }
  });

  app.get("/api/download-database", (_req, res) => {
    try {
      const catalog = JSON.parse(fs.readFileSync(catalogPath, "utf8"));
      const db = JSON.parse(fs.readFileSync(dbPath, "utf8"));

      const catalogByName = new Map<string, any>();
      for (const entry of catalog) {
        catalogByName.set(entry.name, entry);
      }

      const allEntries: any[] = [];

      for (const entry of catalog) {
        allEntries.push({
          ...entry,
          source: entry.inDatabase ? "both" : "text",
        });
      }

      for (const node of db.nodes) {
        if (!catalogByName.has(node.name)) {
          allEntries.push({
            name: node.name,
            tradition: node.tradition || "Unknown",
            gender: node.gender || "Unknown",
            domain: node.domain || "",
            object: node.object || null,
            animals: node.animals || null,
            characterTrait: node.characterTrait || null,
            physicalCharacteristics: node.physicalCharacteristics || null,
            significantEvent: node.significantEvent || null,
            symbolism: node.symbolism || null,
            neumannArchetype: null,
            mentionCount: 0,
            inDatabase: true,
            source: "database",
            birthCircumstances: node.birthCircumstances || null,
            deathCircumstances: node.deathCircumstances || null,
            eventTypes: node.eventTypes || [],
            birthTypes: node.birthTypes || [],
            deathTypes: node.deathTypes || [],
            familyRoles: node.familyRoles || [],
          });
        }
      }

      const exportData = {
        exportDate: new Date().toISOString(),
        totalEntries: allEntries.length,
        nodes: allEntries,
        edges: db.edges || [],
      };

      res.setHeader("Content-Type", "application/json");
      res.setHeader("Content-Disposition", "attachment; filename=mythology-database.json");
      res.send(JSON.stringify(exportData, null, 2));
    } catch (err) {
      res.status(500).json({ error: "Failed to generate download" });
    }
  });

  app.get("/api/deities/:name", (req, res) => {
    try {
      const catalog = JSON.parse(fs.readFileSync(catalogPath, "utf8"));
      const deity = catalog.find(
        (d: any) => d.name.toLowerCase() === req.params.name.toLowerCase()
      );
      if (!deity) {
        return res.status(404).json({ error: "Deity not found" });
      }
      res.json(deity);
    } catch (err) {
      res.status(500).json({ error: "Failed to load deity" });
    }
  });

  app.post("/api/database/import", (req, res) => {
    try {
      const data = req.body;

      if (!data || typeof data !== "object") {
        return res.status(400).json({ error: "Invalid JSON data" });
      }

      if (!data.nodes || !Array.isArray(data.nodes)) {
        return res.status(400).json({ error: "Database must contain a 'nodes' array" });
      }

      fs.writeFileSync(dbPath, JSON.stringify(data, null, 2));

      const dbNames = new Set(data.nodes.map((n: any) => n.name));
      const catalog = JSON.parse(fs.readFileSync(catalogPath, "utf8"));
      const updatedCatalog = catalog.map((d: any) => ({
        ...d,
        inDatabase: dbNames.has(d.name),
      }));
      fs.writeFileSync(catalogPath, JSON.stringify(updatedCatalog, null, 2));

      const inDB = updatedCatalog.filter((d: any) => d.inDatabase).length;
      const notInDB = updatedCatalog.filter((d: any) => !d.inDatabase).length;

      res.json({
        success: true,
        totalNodes: data.nodes.length,
        totalEdges: data.edges?.length || 0,
        catalogMatches: inDB,
        newEntries: notInDB,
      });
    } catch (err) {
      res.status(500).json({ error: "Failed to import database" });
    }
  });

  app.get("/api/all-entries", (_req, res) => {
    try {
      const catalog = JSON.parse(fs.readFileSync(catalogPath, "utf8"));
      const db = JSON.parse(fs.readFileSync(dbPath, "utf8"));

      const catalogByName = new Map<string, any>();
      for (const entry of catalog) {
        catalogByName.set(entry.name, entry);
      }

      const allEntries: any[] = [];

      for (const entry of catalog) {
        allEntries.push({
          ...entry,
          source: entry.inDatabase ? "both" : "text",
        });
      }

      for (const node of db.nodes) {
        if (!catalogByName.has(node.name)) {
          allEntries.push({
            name: node.name,
            tradition: node.tradition || "Unknown",
            gender: node.gender || "Unknown",
            domain: node.domain || "",
            object: node.object || null,
            animals: node.animals || null,
            characterTrait: node.characterTrait || null,
            physicalCharacteristics: node.physicalCharacteristics || null,
            significantEvent: node.significantEvent || null,
            symbolism: null,
            neumannArchetype: null,
            mentionCount: 0,
            inDatabase: true,
            source: "database",
            birthCircumstances: node.birthCircumstances || null,
            deathCircumstances: node.deathCircumstances || null,
            eventTypes: node.eventTypes || [],
            birthTypes: node.birthTypes || [],
            deathTypes: node.deathTypes || [],
            familyRoles: node.familyRoles || [],
          });
        }
      }

      res.json(allEntries);
    } catch (err) {
      res.status(500).json({ error: "Failed to load entries" });
    }
  });

  app.get("/api/database/nodes", (_req, res) => {
    try {
      const db = JSON.parse(fs.readFileSync(dbPath, "utf8"));
      res.json(db.nodes);
    } catch (err) {
      res.status(500).json({ error: "Failed to load database nodes" });
    }
  });

  app.get("/api/database/stats", (_req, res) => {
    try {
      const db = JSON.parse(fs.readFileSync(dbPath, "utf8"));
      const catalog = JSON.parse(fs.readFileSync(catalogPath, "utf8"));

      const traditions = [...new Set(db.nodes.map((n: any) => n.tradition).filter(Boolean))].sort();
      const catalogTraditions = [...new Set(catalog.map((d: any) => d.tradition).filter(Boolean))].sort();
      const inDB = catalog.filter((d: any) => d.inDatabase).length;
      const notInDB = catalog.filter((d: any) => !d.inDatabase).length;

      res.json({
        totalDatabaseNodes: db.nodes.length,
        totalEdges: db.edges.length,
        totalCatalogEntries: catalog.length,
        inDatabase: inDB,
        newFromText: notInDB,
        databaseTraditions: traditions,
        catalogTraditions: catalogTraditions,
      });
    } catch (err) {
      res.status(500).json({ error: "Failed to compute stats" });
    }
  });

  return httpServer;
}
