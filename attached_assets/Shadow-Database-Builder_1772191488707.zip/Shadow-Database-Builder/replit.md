# Mythology Catalog

## Overview
A web application that displays all deities and mythological figures from two sources:
1. **Shadows-database** — An existing mythology database with ~1,128 nodes and 400+ edges
2. **"The Great Mother" by Erich Neumann** — 83 entries extracted from the scholarly text with detailed archetypal analysis

The app merges both sources into a unified, searchable catalog showing which entries come from the text, the database, or both.

## Architecture
- **Backend**: Express.js serving merged JSON data via REST API
- **Frontend**: React + TypeScript with Vite, using shadcn/ui components and TanStack Query
- **Data**: Pre-extracted deity catalog (JSON) + shadows-database (JSON), merged at runtime

## Data Sources
- `attached_assets/The_great_mother_1772036644012.docx` — 33,465-line .docx of Neumann's text (source for extraction)
- `attached_assets/shadows-database_1772036446426.json` — Existing mythology database (replaceable via import)
- `server/data/deity-catalog.json` — Extracted deity data from "The Great Mother"

## API Endpoints
- `GET /api/all-entries` — Unified catalog merging both sources, with `source` field ("text", "database", or "both")
- `GET /api/deities` — Catalog entries only (83 from Great Mother text)
- `GET /api/deities/:name` — Single deity by name
- `GET /api/deities/download-new` — Download entries not yet in database as JSON
- `GET /api/database/nodes` — All shadows-database nodes
- `GET /api/database/stats` — Cross-reference statistics
- `POST /api/database/import` — Replace shadows-database with uploaded JSON (requires `nodes` array, 50mb limit)

## Key Files
- `server/data/deity-catalog.json` — Extracted deity data with fields: name, tradition, gender, domain, object, animals, characterTrait, physicalCharacteristics, significantEvent, symbolism, neumannArchetype, mentionCount, inDatabase, eventTypes, birthTypes, deathTypes
- `server/routes.ts` — API routes including merged `/api/all-entries` endpoint
- `client/src/pages/home.tsx` — Main catalog UI with search, filter by tradition/source/event type/birth type/death type, sort, and detail dialogs

## Normalized Event Types
Significant events are classified into 23 normalized types for cross-character comparison:

**Conflict**: slays_monster, slays_kin, overthrows_ruler, vengeance, contest
**Transformation**: curse, punishment, loss_of_power, apotheosis
**Journey**: descent_to_underworld, quest, exile, abduction
**Creation**: world_creation, humanity_creation, gift_to_humanity, founding, invention
**Relational**: divine_marriage, seduction, betrayal, rescue
**Sacrifice**: sacrifice

302 characters tagged via LLM classification (gpt-4o-mini).

## Normalized Birth Types
Birth circumstances are classified into 12 categories:
- divine_parentage, demigod_birth, mortal_parentage, parthenogenesis
- primordial_emergence, born_from_body, born_from_element, miraculous_conception
- incestuous_union, abandoned_at_birth, royal_lineage, prophesied_birth

407 characters tagged with birth types.

## Normalized Death Types
Death circumstances are classified into 15 categories:
- killed_in_battle, killed_by_god, killed_by_hero, killed_by_kin
- self_sacrifice, suicide, dismemberment, transformation_at_death
- immortality_denied, sacrificed_ritually, betrayed_and_killed
- natural_death, eternal_punishment, resurrection, prophesied_death

60 characters tagged with death types.

## Family Roles
Characters are classified into 4 family roles:
- mother, father, sister, brother

410 characters tagged with family roles (father: 177, mother: 170, brother: 50, sister: 44).

## Data Normalization
All categorical fields have been fully normalized:
- **Gender**: Standardized to Male/Female/Non-binary (LLM-classified, only 1 entry remains empty)
- **Tradition**: Consolidated from 39 variants to 19 canonical values
- **Animals**: Singular forms only, duplicates removed
- **Objects**: Singular forms only, duplicates removed
- **Event Types**: 23 normalized categories, LLM-classified (302/417 tagged)
- **Birth Types**: 12 normalized categories, LLM-classified (407/428 tagged)
- **Death Types**: 15 normalized categories, LLM-classified (60/76 tagged)
- **Family Roles**: 4 categories, LLM-classified (410/1211 tagged)

## Features
- Unified view of all entries from both sources
- Source filter: Text Only (new), Database Only, In Both
- Tradition filter with all traditions from both sources
- Event type filter: filter by any of the 23 normalized event types
- Birth type filter: filter by any of the 12 normalized birth types
- Death type filter: filter by any of the 15 normalized death types
- Family role filter: filter by mother, father, sister, or brother
- Search across name, domain, traits, symbols, animals
- Sort by name, mentions, or tradition
- Detail dialog with all available fields including event/birth/death type badges
- Color-coded type badges on cards and detail views
- Import new database JSON to replace shadows-database
- Download new entries not yet in database
