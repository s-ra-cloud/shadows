# Religious and Mythology Full-Text Hunter

A rights-aware collector for **complete religious and mythological source
texts**.

The hunter's responsibility is to discover or receive candidate editions,
assess their rights evidence, choose preferred languages, and download the
complete source bytes unchanged. It does **not** extract information about
divinities. Deity extraction remains available as an explicitly separate,
downstream compatibility stage for the supplied JSON files.

## Hunter workflow

1. A source adapter or researcher creates one candidate record per complete
   edition.
2. `plan` assesses that edition's rights evidence and applies the language
   policy.
3. `download` retrieves the entire text without normalization, segmentation,
   or entity matching.
4. Publishable editions go to `public/`.
5. Copyrighted, restricted, jurisdiction-mismatched, likely-but-unconfirmed,
   or unknown editions go to `locked/` when research download is authorized.
6. `verify-corpus` checks every byte count, checksum, partition, permission,
   and lock marker.
7. A later process may read the corpus and create deity-linked excerpts.

Availability and publication rights are separate. A publicly accessible URL
does not automatically authorize automated download or republication.

## Language policy

For each work, the default policy selects:

1. a rights-cleared English edition, when available;
2. a rights-cleared original-language edition;
3. when no cleared English exists, a cleared edition in a configured
   AI-translatable language;
4. if no cleared edition exists, an authorized research copy in English and/or
   the original language, stored under lock.

Translations are separate copyrightable editions. An ancient original may be
public domain while a modern English translation remains copyrighted.

The editable policy is
[config/collection-policy.json](config/collection-policy.json). It currently
targets France, prioritizes text/TEI before presentation formats, and never
unlocks a work based only on a date calculation.

## Rights and lock policy

The assessment engine recognizes:

- explicit public-domain declarations with stated territories;
- CC0 and Public Domain Mark;
- CC BY and CC BY-SA, retaining their attribution/share-alike obligations;
- restricted Creative Commons variants such as NC or ND;
- standardized RightsStatements.org `NoC-*` and `InC-*` identifiers;
- explicit copyright notices and “all rights reserved” markers;
- U.S.-only public-domain statements;
- conservative France/EU life-plus-70 and U.S. publication-date heuristics.

Only explicit public-domain evidence covering France/EU/worldwide, CC0, CC BY,
or CC BY-SA is unlocked by default. Everything else is marked
`do_not_publish: true`.

A locked download receives three safeguards:

- storage below `locked/`, separate from publishable files;
- an adjacent `.LOCK.json` marker;
- owner-only `0600` filesystem permissions.

The lock is an accident-prevention control, not DRM and not legal advice.
Professional review is still appropriate before publication.

The policy follows these authoritative baselines:

- France's [Code de la propriété intellectuelle, article
  L123-1](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000006278937/2025-02-13)
  generally continues economic rights through the author's life and the next
  seventy calendar years.
- The EU [Copyright Term
  Directive](https://eur-lex.europa.eu/eli/dir/2006/116/oj/eng) harmonizes a
  general life-plus-70 term while also defining special cases.
- The U.S. Copyright Office's [Duration of Copyright, Circular
  15A](https://www.copyright.gov/circs/circ15a.pdf) documents the more complex
  U.S. rules. Date calculations are therefore review signals, not automatic
  publication permission.
- [Project Gutenberg's licence
  guidance](https://www.gutenberg.org/policy/license) says its determinations
  are U.S.-specific and distinguishes unrestricted works from copyrighted
  works posted with permission. Its embedded ebook notice is checked.
- [Wikisource copyright
  policy](https://wikisource.org/wiki/Wikisource:Copyright_policy) requires
  public-domain or compatible free-licensed content, including translations,
  but the page-level copyright template is still recorded.
- [Creative Commons licence
  conditions](https://creativecommons.org/share-your-work/use-remix/cc-licenses/)
  are preserved as machine-readable obligations.

See [docs/rights-and-lock-policy.md](docs/rights-and-lock-policy.md) for the
decision table.

## Quick start

Run from the project folder:

```bash
cd /Users/sacharaoult/Documents/religious-mythology-resource-hunter
```

Assess the example editions without downloading:

```bash
python3 -m religious_mythology_resource_hunter plan \
  --candidates examples/fulltext-candidates.jsonl \
  --output data/download-plan.jsonl \
  --assessed-at 2026-07-29T12:00:00+00:00
```

Download preferred full editions:

```bash
python3 -m religious_mythology_resource_hunter download \
  --candidates examples/fulltext-candidates.jsonl \
  --output corpus \
  --selection preferred \
  --assessed-at 2026-07-29T12:00:00+00:00
```

Verify the resulting corpus:

```bash
python3 -m religious_mythology_resource_hunter verify-corpus \
  --corpus corpus
```

Use `--selection all` to download every candidate whose source and per-edition
access metadata authorize download. Non-publishable editions remain locked.

## Corpus layout

```text
corpus/
├── corpus.jsonl
├── README.txt
├── public/
│   └── <work>/<edition>.<format>
├── locked/
│   └── <work>/<edition>.<format>
│       └── adjacent .LOCK.json marker
└── rights/
    └── <work>/<edition>.rights.json
```

`corpus.jsonl` records the selected language reason, source URL/path, rights
evidence, target jurisdiction, obligations, download status, byte count,
SHA-256 checksum, content type, local path, and lock state.

The downloaded text itself is byte-for-byte identical to the source payload.

## Candidate records

Each JSONL candidate represents one edition and includes:

- `work_id` and `edition_id`;
- title, author, translator, language, and language role;
- complete-text URL or reviewed local path;
- source ID and file format;
- publication and edition-copyright-author dates where known;
- exact rights statement, licence URL, rights URL, and territories;
- whether automated/research download is authorized.

Copy [examples/fulltext-candidate-template.json](examples/fulltext-candidate-template.json)
when adding an edition. The schema is
[schemas/v1/fulltext-candidate.schema.json](schemas/v1/fulltext-candidate.schema.json).

Source-level automated-access rules are separate in
[sources/fulltext-registry.json](sources/fulltext-registry.json). The downloader
rejects unknown hosts, disallowed paths, authentication requirements, sources
disabled for automation, and robots exclusions.

Project Gutenberg's official [robot-access
guidance](https://www.gutenberg.org/policy/robot_access.html) says not to crawl
human-facing pages and instead use its catalog/harvest/mirroring facilities.
The bundled Project Gutenberg source therefore remains disabled until an
approved mirror is configured.

## Downstream extraction—separate from the hunter

The supplied `shadows-export-2026-07-29.json` and
`deity_excerpts.jsonl` are still useful after collection:

```bash
python3 -m religious_mythology_resource_hunter build-catalog \
  --input \
  /Users/sacharaoult/Downloads/shadows-export-2026-07-29.json \
  /Users/sacharaoult/Downloads/deity_excerpts.jsonl \
  --output data/entity-catalog.json
```

Then a deliberately separate command can derive excerpts from a downloaded
full text:

```bash
python3 -m religious_mythology_resource_hunter extract \
  --catalog data/entity-catalog.json \
  --registry examples/fixture-source-registry.json \
  --source-id source:synthetic-tei-fixture \
  --input tests/fixtures/sample_tei.xml \
  --output data/example-excerpts.jsonl
```

These downstream records remain compatible with `deity_excerpts.jsonl`; they
are not the hunter's primary storage format.

## Tests

The project uses only the Python standard library:

```bash
PYTHONPYCACHEPREFIX=/tmp/rmrh-pycache \
  python3 -m unittest discover -s tests -v
```

The tests verify full-byte preservation, rights decisions, language selection,
public/locked separation, lock permissions, checksums, resume behavior, and
the older downstream extraction adapters.

## Important limits

- The system records evidence and applies a conservative policy; it cannot
  replace a jurisdiction-specific legal opinion.
- Anonymous, collaborative, posthumous, unpublished, restored foreign, crown,
  liturgical, traditional-cultural-expression, and database rights may need
  special analysis.
- An original work and every translation, edition, introduction, annotation,
  and transcription may have different rights.
- A rights statement can be wrong. Its source URL, wording, territory, basis,
  and assessment time are retained for audit.
- Sacred or community-restricted texts may require a cultural lock even when
  copyright has expired. The candidate model can keep those editions locked by
  declaring a restriction rather than a publishable licence.
- AI translation is a candidate-generation aid. It requires linguistic and
  scholarly review and is never treated as a faithful authoritative
  translation automatically.

