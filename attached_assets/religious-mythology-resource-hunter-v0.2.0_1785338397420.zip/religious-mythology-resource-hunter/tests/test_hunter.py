import json
from datetime import datetime, timezone
from pathlib import Path
import tempfile
import unittest
from copy import deepcopy

from religious_mythology_resource_hunter.catalog import (
    entities_from_jsonl,
    load_catalog,
    merge_entities,
    write_catalog,
)
from religious_mythology_resource_hunter.iiif import IiifAdapter
from religious_mythology_resource_hunter.legacy_jsonl import LegacyJsonlAdapter
from religious_mythology_resource_hunter.matching import EntityMatcher
from religious_mythology_resource_hunter.mediawiki import MediaWikiAdapter
from religious_mythology_resource_hunter.oai_dc import OaiDcAdapter
from religious_mythology_resource_hunter.pipeline import (
    merge_jsonl,
    parse_payload,
    prepare_records,
    write_jsonl,
)
from religious_mythology_resource_hunter.plain_text import PlainTextAdapter
from religious_mythology_resource_hunter.tei import TeiAdapter
from religious_mythology_resource_hunter.validation import (
    load_registry,
    validate_source_registry,
    validate_jsonl,
    validate_record,
)


ROOT = Path(__file__).parents[1]
FIXTURES = ROOT / "tests" / "fixtures"
NOW = datetime(2026, 7, 29, 12, 0, tzinfo=timezone.utc)


def source(source_family, **defaults):
    return {
        "source_id": f"source:test-{source_family.replace('_', '-')}",
        "name": "Example Collection",
        "source_family": source_family,
        "endpoint_url": "https://museum.example.org/api",
        "resource_types": [
            "text_excerpt",
            "art_description",
            "museum_object",
        ],
        "defaults": defaults,
        "access": {
            "review_status": "reviewed",
            "terms_url": "https://museum.example.org/terms",
            "robots_url": "https://museum.example.org/robots.txt",
            "license": "Public-domain fixture",
            "reuse_notes": "Synthetic fixture.",
        },
        "rate_limit": {"requests_per_second": 0.5},
    }


class CatalogAndMatchingTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.entities = load_catalog(FIXTURES / "shadows_sample.json")

    def test_shadows_export_becomes_entity_catalog(self):
        self.assertEqual(len(self.entities), 5)
        athena = next(entity for entity in self.entities if entity.name == "Athena")
        self.assertEqual(athena.gender, "female")
        self.assertIn("Pallas Athena", athena.aliases)

    def test_short_aliases_are_case_sensitive(self):
        matcher = EntityMatcher(self.entities)
        self.assertEqual([match.entity.name for match in matcher.find("Ra rose.")], ["Ra"])
        self.assertEqual(matcher.find("The syllable ra occurs."), [])

    def test_canonical_names_are_case_insensitive_but_alternatives_are_exact(self):
        matcher = EntityMatcher(self.entities)
        matches = matcher.find("Jupiter spoke to Pallas Athena and ZEUS.")
        self.assertEqual(
            {match.entity.name for match in matches},
            {"Zeus", "Athena"},
        )
        self.assertEqual(matcher.find("jupiter"), [])

    def test_catalog_round_trip(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "catalog.json"
            write_catalog(path, self.entities)
            self.assertEqual(load_catalog(path), self.entities)

    def test_resource_jsonl_enriches_alias_catalog(self):
        resources = entities_from_jsonl(FIXTURES / "sample_legacy.jsonl")
        merged = merge_entities(self.entities + resources)
        athena = next(entity for entity in merged if entity.name == "Athena")
        self.assertIn("Pallas Athena", athena.aliases)
        self.assertIn("Athena", athena.aliases)

    def test_known_false_positive_alias_is_not_reimported(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "noise.jsonl"
            path.write_text(
                json.dumps(
                    {
                        "deity": "Hera",
                        "tradition": "Greek",
                        "gender": "female",
                        "matched_alias": "Here",
                    }
                )
                + "\n"
            )
            [hera] = entities_from_jsonl(path)
            self.assertEqual(hera.aliases, ("Hera",))


class AdapterTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.entities = load_catalog(FIXTURES / "shadows_sample.json")

    def run_adapter(self, adapter, fixture, source_definition):
        payload = (FIXTURES / fixture).read_bytes()
        records = adapter.parse_sample(
            payload,
            source=source_definition,
            entities=self.entities,
            retrieved_at=NOW,
        )
        for record in records:
            validate_record(record)
        return records

    def test_plain_text_adapter(self):
        records = self.run_adapter(
            PlainTextAdapter(),
            "sample_plain.txt",
            source(
                "plain_text",
                source_work="Sample Source",
                source_author="Anonymous",
                corpus="test",
                origin="primary_source",
                locator="urn:test:plain",
            ),
        )
        self.assertEqual(
            {record["deity"] for record in records},
            {"Athena", "Zeus", "Ra"},
        )
        self.assertNotIn(
            "ra",
            {record["matched_alias"] for record in records},
        )

    def test_tei_adapter_extracts_header_and_locators(self):
        records = self.run_adapter(
            TeiAdapter(),
            "sample_tei.xml",
            source("tei", corpus="greek", origin="primary_source"),
        )
        self.assertEqual(
            {record["deity"] for record in records},
            {"Zeus", "Athena", "Ra"},
        )
        self.assertTrue(all(record["source_work"] == "Sample Hymns" for record in records))
        self.assertTrue(
            all(record["translator"] == "Example Translator" for record in records)
        )
        self.assertTrue(any(record["locator"].endswith("#hymn-1") for record in records))

    def test_iiif_adapter_emits_museum_fields(self):
        records = self.run_adapter(
            IiifAdapter(),
            "sample_iiif.json",
            source("iiif", corpus="museum", origin="museum_catalog_modern"),
        )
        self.assertEqual(len(records), 1)
        record = records[0]
        self.assertEqual(record["deity"], "Athena")
        self.assertEqual(record["record_type"], "museum_object")
        self.assertEqual(record["artwork_medium"], "Marble")
        self.assertEqual(record["match_confidence"], "high")
        self.assertEqual(record["source_author"], "Example Museum")

    def test_oai_dc_adapter_emits_museum_record(self):
        records = self.run_adapter(
            OaiDcAdapter(),
            "sample_oai_dc.xml",
            source("oai_dc", corpus="museum", origin="museum_catalog_modern"),
        )
        self.assertEqual(len(records), 1)
        self.assertEqual(records[0]["deity"], "Shiva")
        self.assertEqual(records[0]["artwork_classification"], "Sculpture")
        self.assertEqual(records[0]["locator"], "oai:example.org:shiva-1")

    def test_mediawiki_handles_file_and_text_pages(self):
        records = self.run_adapter(
            MediaWikiAdapter(),
            "sample_mediawiki.json",
            source("mediawiki", corpus="mixed", origin="primary_source"),
        )
        by_deity = {record["deity"]: record for record in records}
        self.assertEqual(set(by_deity), {"Bast", "Zeus", "Athena"})
        self.assertEqual(by_deity["Bast"]["record_type"], "museum_object")
        self.assertEqual(by_deity["Zeus"]["matched_alias"], "Jupiter")

    def test_legacy_adapter_is_lossless(self):
        payload = (FIXTURES / "sample_legacy.jsonl").read_bytes()
        records = LegacyJsonlAdapter().parse_sample(
            payload,
            source=source("legacy_jsonl"),
            entities=self.entities,
            retrieved_at=NOW,
        )
        self.assertEqual(len(records), 2)
        self.assertEqual(records[1]["artwork_title"], "Bast statuette")
        for record in records:
            validate_record(record)

    def test_adapter_boundary_selects_family_and_validates(self):
        payload = (FIXTURES / "sample_tei.xml").read_bytes()
        records = parse_payload(
            payload,
            source=source("tei", corpus="greek", origin="primary_source"),
            entities=self.entities,
            retrieved_at=NOW,
        )
        self.assertEqual(len(records), 3)


class PipelineTests(unittest.TestCase):
    def test_prepare_deduplicates_and_reindexes(self):
        records = [
            json.loads(line)
            for line in (FIXTURES / "sample_legacy.jsonl").read_text().splitlines()
            if line.strip()
        ]
        prepared = prepare_records(
            [records[0], records[0], records[1]], sequential_ids=True
        )
        self.assertEqual(len(prepared), 2)
        self.assertEqual(
            [record["id"] for record in prepared],
            ["rec000000", "rec000001"],
        )

    def test_merge_writes_valid_jsonl(self):
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory) / "merged.jsonl"
            records = merge_jsonl(
                [
                    FIXTURES / "sample_legacy.jsonl",
                    FIXTURES / "sample_legacy.jsonl",
                ],
                output,
            )
            self.assertEqual(len(records), 2)
            self.assertEqual(validate_jsonl(output), 2)

    def test_registry_is_valid_and_has_unique_sources(self):
        registry = load_registry(ROOT / "sources" / "registry.json")
        self.assertEqual(len(registry["sources"]), 3)
        self.assertEqual(
            len({item["source_id"] for item in registry["sources"]}),
            3,
        )

    def test_registry_rejects_unreviewed_shape(self):
        registry = load_registry(ROOT / "sources" / "registry.json")
        invalid = deepcopy(registry)
        invalid["sources"][0]["access"]["review_status"] = "unknown"
        with self.assertRaisesRegex(ValueError, "review_status"):
            validate_source_registry(invalid)

    def test_write_jsonl_preserves_unicode(self):
        record = json.loads(
            (FIXTURES / "sample_legacy.jsonl").read_text().splitlines()[0]
        )
        record["excerpt"] = "Athena protège la cité."
        record["n_words"] = 4
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory) / "unicode.jsonl"
            write_jsonl(output, [record])
            self.assertIn("protège", output.read_text())


if __name__ == "__main__":
    unittest.main()
