from copy import deepcopy
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import tempfile
import unittest

from religious_mythology_resource_hunter.fulltext import (
    collect_fulltexts,
    verify_corpus,
)
from religious_mythology_resource_hunter.fulltext_sources import (
    load_fulltext_registry,
)
from religious_mythology_resource_hunter.fulltext_validation import (
    load_candidates,
    load_policy,
)
from religious_mythology_resource_hunter.planning import plan_candidates
from religious_mythology_resource_hunter.rights import assess_rights


ROOT = Path(__file__).parents[1]
NOW = datetime(2026, 7, 29, 12, 0, tzinfo=timezone.utc)


class RightsTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.policy = load_policy(ROOT / "config" / "collection-policy.json")
        cls.candidates = load_candidates(
            ROOT / "examples" / "fulltext-candidates.jsonl"
        )

    def assessment(self, candidate, embedded_notice=""):
        return assess_rights(
            candidate,
            self.policy,
            embedded_notice=embedded_notice,
            assessed_at=NOW,
        )

    def test_cc_by_sa_is_publishable_and_translatable(self):
        result = self.assessment(self.candidates[0])
        self.assertEqual(result["status"], "open_license")
        self.assertTrue(result["publication_allowed"])
        self.assertTrue(result["translation_allowed"])
        self.assertFalse(result["locked"])
        self.assertIn("share_alike", result["obligations"])

    def test_no_derivatives_license_is_locked_for_translation_workflow(self):
        candidate = deepcopy(self.candidates[0])
        candidate["rights"] = {
            "status_claim": "open_license",
            "statement": "Creative Commons Attribution-NoDerivatives 4.0",
            "license": "CC BY-ND 4.0",
            "license_url": "https://creativecommons.org/licenses/by-nd/4.0/",
            "territories": ["WORLDWIDE"],
            "basis": "source_metadata",
        }
        result = self.assessment(candidate)
        self.assertEqual(result["status"], "restricted_license")
        self.assertTrue(result["locked"])
        self.assertFalse(result["translation_allowed"])

    def test_us_only_public_domain_claim_stays_locked_in_france(self):
        candidate = deepcopy(self.candidates[0])
        candidate["rights"] = {
            "status_claim": "unknown",
            "statement": (
                "This ebook is not protected by copyright in the United States."
            ),
            "license": None,
            "territories": ["US"],
            "basis": "embedded_notice",
        }
        result = self.assessment(candidate)
        self.assertEqual(
            result["status"], "public_domain_jurisdictional"
        )
        self.assertTrue(result["locked"])
        self.assertFalse(result["publication_allowed"])

    def test_gutenberg_permission_notice_beats_generic_us_license_text(self):
        candidate = deepcopy(self.candidates[0])
        candidate["rights"] = {
            "status_claim": "unknown",
            "statement": "",
            "license": None,
            "territories": ["US"],
            "basis": "embedded_notice",
        }
        result = self.assessment(
            candidate,
            embedded_notice=(
                "Books not restricted by U.S. copyright law. "
                "This particular work is posted with permission of the "
                "copyright holder."
            ),
        )
        self.assertEqual(result["status"], "copyrighted")
        self.assertTrue(result["locked"])

    def test_life_plus_seventy_is_only_likely_until_reviewed(self):
        candidate = deepcopy(self.candidates[0])
        candidate["rights"] = {
            "status_claim": "unknown",
            "statement": "",
            "license": None,
            "territories": [],
            "basis": "unknown",
        }
        candidate["copyright_author_death_year"] = 1900
        result = self.assessment(candidate)
        self.assertEqual(result["status"], "public_domain_likely")
        self.assertTrue(result["locked"])
        self.assertTrue(result["review_required"])

    def test_embedded_copyright_notice_overrides_unknown(self):
        candidate = deepcopy(self.candidates[0])
        candidate["rights"] = {
            "status_claim": "unknown",
            "statement": "",
            "license": None,
            "territories": [],
            "basis": "unknown",
        }
        result = self.assessment(
            candidate,
            embedded_notice="Copyright 2026. All rights reserved.",
        )
        self.assertEqual(result["status"], "copyrighted")
        self.assertTrue(result["do_not_publish"])

    def test_conflicting_open_and_restrictive_markers_are_locked(self):
        candidate = deepcopy(self.candidates[0])
        result = self.assessment(
            candidate,
            embedded_notice="Copyright 2026. All rights reserved.",
        )
        self.assertEqual(result["status"], "conflicting")
        self.assertTrue(result["locked"])
        self.assertIn(
            "resolve_conflicting_rights_evidence",
            result["obligations"],
        )


class PlanningTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.policy = load_policy(ROOT / "config" / "collection-policy.json")
        cls.candidates = load_candidates(
            ROOT / "examples" / "fulltext-candidates.jsonl"
        )

    def test_policy_selects_open_english_plus_original_then_fallback(self):
        plans = plan_candidates(
            self.candidates, self.policy, assessed_at=NOW
        )
        reasons = {
            plan["candidate"]["edition_id"]: plan["selection"]["reason"]
            for plan in plans
        }
        self.assertEqual(
            reasons["edition:city-goddess-en-open"],
            "preferred_open_english",
        )
        self.assertEqual(
            reasons["edition:city-goddess-grc-original"],
            "preferred_open_original",
        )
        self.assertEqual(
            reasons["edition:city-goddess-fr-locked"],
            "not_selected",
        )
        self.assertEqual(
            reasons["edition:ancient-ritual-sa-original"],
            "preferred_open_original",
        )
        self.assertEqual(
            reasons["edition:ancient-ritual-la-open"],
            "fallback_open_ai_translatable",
        )
        self.assertEqual(
            reasons["edition:modern-divinity-study-en-locked"],
            "locked_english_reference",
        )


class CorpusDownloadTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.policy = load_policy(ROOT / "config" / "collection-policy.json")
        cls.candidates = load_candidates(
            ROOT / "examples" / "fulltext-candidates.jsonl"
        )
        cls.registry = load_fulltext_registry(
            ROOT / "sources" / "fulltext-registry.json"
        )

    def test_full_bytes_are_partitioned_and_locked(self):
        with tempfile.TemporaryDirectory() as directory:
            corpus = Path(directory) / "corpus"
            records = collect_fulltexts(
                self.candidates,
                self.policy,
                self.registry,
                corpus,
                assessed_at=NOW,
            )
            statuses = [record["download_status"] for record in records]
            self.assertEqual(statuses.count("downloaded"), 5)
            self.assertEqual(statuses.count("not_selected"), 1)

            modern = next(
                record
                for record in records
                if record["edition_id"]
                == "edition:modern-divinity-study-en-locked"
            )
            self.assertTrue(modern["file"]["locked"])
            self.assertTrue(
                modern["file"]["relative_path"].startswith("locked/")
            )
            locked_path = corpus / modern["file"]["relative_path"]
            source_path = (
                ROOT
                / "tests"
                / "fixtures"
                / "fulltexts"
                / "modern_study_en.txt"
            )
            self.assertEqual(locked_path.read_bytes(), source_path.read_bytes())
            self.assertEqual(locked_path.stat().st_mode & 0o077, 0)
            self.assertTrue(
                (corpus / modern["file"]["lock_path"]).is_file()
            )
            self.assertTrue(
                (corpus / modern["file"]["rights_path"]).is_file()
            )

            english = next(
                record
                for record in records
                if record["edition_id"] == "edition:city-goddess-en-open"
            )
            self.assertFalse(english["file"]["locked"])
            self.assertTrue(
                english["file"]["relative_path"].startswith("public/")
            )
            counts = verify_corpus(corpus)
            self.assertEqual(counts["downloaded"], 5)
            self.assertEqual(counts["public"], 4)
            self.assertEqual(counts["locked"], 1)
            self.assertEqual(counts["not_selected"], 1)

    def test_resume_never_overwrites_full_text(self):
        with tempfile.TemporaryDirectory() as directory:
            corpus = Path(directory) / "corpus"
            collect_fulltexts(
                self.candidates,
                self.policy,
                self.registry,
                corpus,
                assessed_at=NOW,
            )
            second = collect_fulltexts(
                self.candidates,
                self.policy,
                self.registry,
                corpus,
                assessed_at=NOW,
            )
            statuses = [record["download_status"] for record in second]
            self.assertEqual(statuses.count("already_present"), 5)


if __name__ == "__main__":
    unittest.main()
