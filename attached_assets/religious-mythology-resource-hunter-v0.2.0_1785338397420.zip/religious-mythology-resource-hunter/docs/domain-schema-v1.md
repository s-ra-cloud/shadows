# Downstream excerpt schema v1

This schema describes derived deity-linked excerpts created after full-text
collection. The hunter's primary record is
[`corpus-record.schema.json`](../schemas/v1/corpus-record.schema.json), and the
complete source file remains the authoritative stored object.

## Decision

Within this downstream format, the storage unit is one evidence excerpt linked
to one catalog figure. JSONL is used because it is streamable, appendable,
diffable, and already used by the supplied 50,121-record corpus.

The union of fields observed in `deity_excerpts.jsonl` is authoritative for
version 1. No top-level envelope is added. Retrieval and rights metadata are
stored in a neighboring provenance JSON document.

## Required fields

The required fields are:

`deity`, `tradition`, `gender`, `matched_alias`, `record_type`, `source_work`,
`source_author`, `translator`, `corpus`, `origin`, `locator`, `excerpt`,
`n_words`, and `id`.

The allowed record types are:

- `text_excerpt`: prose, verse, scripture, commentary, translation, or other
  textual passage;
- `art_description`: a primary-source passage describing an image, structure,
  ritual object, monument, or artwork;
- `museum_object`: a modern collection description for a physical or digital
  cultural-heritage object.

## Conditional fields

Every `museum_object` requires:

- `url`;
- `artwork_title`;
- `artwork_date`;
- `artwork_medium`;
- `artwork_classification`;
- `match_confidence`.

Translation-aware records may include:

- `excerpt_original`;
- `original_language`;
- `translation_method`;
- `translator_note`.

## Identity and deduplication

Adapters initially create a stable ID from the figure, tradition, record type,
locator, and excerpt. Final export uses `rec000000`-style sequential IDs by
default for exact compatibility with the reference corpus. `--keep-stable-ids`
retains content-hash IDs.

Deduplication compares every field except `id`. It therefore does not collapse
two figures mentioned in the same excerpt or two different locators containing
the same prose.

## Semantics

`deity` retains the historical field name for compatibility. It may refer more
broadly to a deity, spirit, saint, angel, demon, hero, ancestor, mythic animal,
personified concept, legendary figure, or other catalog entity. A future major
schema may introduce a neutral field such as `entity`; version 1 does not
silently rename the field.

`tradition` describes the catalog context of the matched figure. It is not an
assertion that the source author, community, or holding institution uses the
same classification.

`matched_alias` is evidence of a string match only. It does not establish
identity, equivalence, influence, or syncretism.
