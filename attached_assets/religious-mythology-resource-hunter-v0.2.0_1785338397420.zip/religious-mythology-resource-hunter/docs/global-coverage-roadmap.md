# Global coverage roadmap

“All religious and mythological resources” is a long-term coverage objective,
not a finite scrape. Coverage must be measured across four dimensions.

## 1. Traditions and communities

The queue should deliberately cover, without collapsing:

- ancient Mediterranean and Near Eastern traditions;
- Jewish, Christian, Islamic, Baháʼí, Mandaean, Yazidi, Druze, Samaritan, and
  other West Asian traditions;
- Hindu, Buddhist, Jain, Sikh, Adivasi, and regional South Asian traditions;
- Chinese, Daoist, Confucian, Buddhist, Korean, Japanese/Shinto, Ryukyuan,
  Ainu, Mongolian, Tibetan, and Central Asian traditions;
- African and African-diasporic religions and oral traditions;
- Indigenous traditions of the Americas;
- Aboriginal Australian, Māori, Polynesian, Micronesian, Melanesian, and other
  Pacific traditions;
- European, Eurasian, circumpolar, folk, vernacular, and reconstructed
  traditions;
- cross-cultural literary, fairy-tale, legendary, and syncretic corpora.

Community-preferred names and restrictions must take precedence over a
collector's convenience. A public endpoint is not proof that aggregation is
culturally appropriate.

## 2. Languages and full editions

Track original language, script, edition, translator, translation date, and
licence separately. Do not treat translations as interchangeable. Prioritize
rights-cleared English plus the original language. When cleared English is
unavailable, select a cleared configured AI-translatable language while
retaining the original. AI translation is a later derived artifact, never a
replacement for the downloaded source.

## 3. Complete text resources

Collect complete, edition-identified source files for:

- scripture, hymn, epic, myth, drama, chronicle, commentary, folklore, and oral
  transcription;
- TEI/XML scholarly editions;
- plain-text and HTML transcriptions;
- EPUB or PDF when a structured text is unavailable;
- manuscript, inscription, papyrus, tablet, and codex transcriptions;
- museum or archival descriptions when they themselves are complete textual
  sources.

Images, audio, and video binaries remain outside the current full-text phase.

## 4. Evidence quality

Measure:

- reviewed sources by family;
- traditions, regions, languages, and scripts;
- unique works, editions, and full-text files;
- checksum-verified bytes and immutable source references;
- rights decisions with exact statements, territories, licences, and dates;
- public, locked, metadata-only, failed, and excluded counts;
- original-language/translation pairs;
- known gaps and culturally restricted exclusions.

## Next adapters

1. Project Gutenberg RDF/OPDS catalog discovery plus an operator-configured
   official mirror, with embedded ebook notice checks.
2. Multilingual Wikisource work/subpage export with page-level copyright
   template capture.
3. Perseus/Open Greek and Latin repository discovery with per-edition licence
   and translator metadata.
4. Sefaria version discovery with version-specific language and licence fields.
5. Internet Archive metadata discovery restricted to items with explicit
   full-text access and rights evidence.
6. CTS/CapiTainS work discovery while downloading the complete TEI edition.
7. OCR/HTR import as a separate, confidence-marked derived-text workflow.

No adapter should move to unattended collection until its sample, rights,
robots, rate, attribution, edition-identity, and complete-file review is
complete.
