# Full-text source contract

## Boundary

A source-discovery adapter emits candidate metadata. The downloader retrieves
the complete edition bytes. Neither component extracts deity information.

Each candidate follows
`schemas/v1/fulltext-candidate.schema.json` and identifies exactly one
edition/translation.

## Source registry

Every remote source records:

- stable source ID and name;
- whether local-only or remote;
- allowed hosts and path prefixes;
- whether automated download is enabled;
- terms URL;
- robots-check mode;
- conservative requests per second;
- rights caveats.

Candidate access permission and source permission must both allow download.
Authentication and access-control bypass are unsupported.

## Candidate requirements

Required:

- stable work and edition IDs;
- title and authorship;
- ISO-like language code and `original`/`translation`/`parallel` role;
- complete-text HTTPS URL or reviewed local path;
- format;
- exact edition-level rights evidence;
- explicit `download_allowed` boolean.

Recommended:

- translator;
- original language;
- metadata record URL;
- publication year;
- copyright-relevant author/translator death year;
- standardized licence or rights URL;
- territories and evidence basis.

## Content invariant

The stored file is the response body or local payload unchanged. The downloader
does not:

- strip Project Gutenberg headers;
- convert HTML/TEI/PDF to plain text;
- normalize Unicode or whitespace;
- segment passages;
- translate;
- match entity aliases;
- add generated text.

Any transformation belongs in a later derived-data pipeline, with its own
checksum relationship back to the immutable source file.

## Automated source acceptance

Before enabling remote retrieval:

1. confirm documented automated access;
2. record terms and robots behavior;
3. restrict hosts and paths;
4. set a conservative rate;
5. demonstrate at least ten complete texts;
6. retain embedded and catalog rights evidence;
7. test pagination/retries without duplicate downloads;
8. review language, edition, and translation identity;
9. review cultural or sacred-access restrictions.

Project Gutenberg specifically directs automation to its catalogs,
harvest/mirror workflows instead of human-facing pages; see [Robot
Access](https://www.gutenberg.org/policy/robot_access.html) and [Offline
Catalogs](https://www.gutenberg.org/ebooks/offline_catalogs.html).

