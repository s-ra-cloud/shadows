# Downstream extraction adapter contract

This contract belongs to the later deity-extraction stage. It is not the
full-text hunter contract. Full-text collection is documented in
[`fulltext-source-contract.md`](fulltext-source-contract.md).

`SourceAdapter` is the deterministic parser boundary. One adapter should cover
one reusable source family rather than one institution.

## Interface

```python
def parse_sample(
    self,
    payload: bytes,
    *,
    source: Mapping[str, Any],
    entities: Iterable[Entity],
    retrieved_at: datetime,
) -> list[dict[str, Any]]:
    ...
```

The adapter receives immutable bytes, a reviewed source definition, an entity
catalog, and an explicit retrieval timestamp. It returns canonical records. It
does not schedule requests, manage a production cursor, write a database, or
publish matches.

`run_sample`:

1. rejects configuration for another adapter family;
2. invokes the deterministic parser;
3. validates every emitted record before it leaves the adapter boundary.

The pipeline then deduplicates, assigns final IDs, validates the complete set,
writes JSONL, and writes a separate provenance sidecar.

## Implemented families

| Family | Input | Typical output |
|---|---|---|
| `legacy_jsonl` | Compatible JSONL | Any existing record type |
| `plain_text` | UTF-8 transcription | `text_excerpt` or `art_description` |
| `tei` | TEI P5 XML | `text_excerpt` or `art_description` |
| `iiif` | Presentation 2.x/3.x manifest | `museum_object` |
| `oai_dc` | OAI-PMH Dublin Core XML | Usually `museum_object` |
| `mediawiki` | Action API JSON | Text excerpts or Commons objects |

## Authoring sequence

1. Research terms, robots policy, licence, attribution, culturally sensitive
   access conditions, and a conservative rate.
2. Add a source definition only after the collection format is confirmed.
3. Capture at least ten distinct immutable samples and their provenance.
4. Write failing positive and false-positive tests.
5. Implement the smallest family parser or configuration change.
6. Validate all records and manually review ambiguous aliases.
7. Document coverage added by language, tradition, geography, and medium.

Do not infer aliases from similar iconography, domains, family roles, or
comparative-religion theories. Add aliases only with explicit catalog evidence.
