# Rights and lock policy

## Purpose

The hunter must decide two different questions for each complete edition:

1. May the system download a research copy from this source?
2. May the system republish or translate that edition?

The first answer comes from source terms, automated-access policy, robots, and
the candidate's access evidence. The second comes from edition-specific
copyright, licence, territory, and cultural restrictions.

An accessible URL is not a rights statement.

## Default decision table

| Evidence | Stored | Online publication | AI translation | Default state |
|---|---:|---:|---:|---|
| Public domain covering FR/EU/worldwide | Yes | Yes | Yes | Public |
| CC0 or Public Domain Mark | Yes | Yes | Yes | Public |
| CC BY | Yes | Yes, with attribution | Yes, with attribution | Public |
| CC BY-SA | Yes | Yes, with attribution/share-alike | Yes, same conditions | Public |
| CC BY-NC or BY-NC-SA | If download authorized | No under default policy | Locked | Locked |
| CC BY-ND or BY-NC-ND | If download authorized | No under default workflow | No derivative translation | Locked |
| RightsStatements.org `NoC-US` targeting France | If download authorized | No until France review | No until review | Locked |
| Restricted `NoC-*` or any `InC-*` | If download authorized | No | No without permission | Locked |
| Explicit copyright/all rights reserved | If download authorized | No | No without permission | Locked |
| Date calculation only | If download authorized | No until reviewed | No until reviewed | Locked |
| Unknown or missing rights | If download authorized | No | No | Locked |

`--selection all` does not override this table. It downloads all
access-authorized candidates but still partitions and locks them.

## Jurisdiction

The supplied policy targets France (`FR`).

[Article L123-1 of the French Code de la propriété
intellectuelle](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000006278937/2025-02-13)
states the general life-plus-70 rule. The EU [Copyright Term
Directive](https://eur-lex.europa.eu/eli/dir/2006/116/oj/eng) includes the
harmonized rule and special categories.

The engine uses a death year only to produce `public_domain_likely`. It does not
account automatically for every exception, co-author, anonymous/pseudonymous
work, posthumous publication, war extension, neighboring right, moral right,
translation, or restored foreign copyright. `unlock_likely_public_domain` is
therefore `false`.

U.S. publication rules vary by publication date and history. The official
[Copyright Office Circular 15A](https://www.copyright.gov/circs/circ15a.pdf)
and [Circular 22](https://www.copyright.gov/circs/circ22.pdf) are starting
points for human review. A U.S.-only determination stays locked under the
France policy.

## Source statements

Project Gutenberg explains that most of its works are unrestricted under U.S.
law, that some copyrighted works are present with permission, and that status
outside the United States must be checked separately. It also warns that the
embedded ebook notice is more authoritative than catalog shorthand. See its
[licence](https://www.gutenberg.org/policy/license) and [permission
guidance](https://www.gutenberg.org/policy/permission.html).

Wikisource requires hosted works and translations to be public domain or
compatible free content, but the work's page-level copyright template remains
important. See [Wikisource copyright
policy](https://wikisource.org/wiki/Wikisource:Copyright_policy).

For Creative Commons works, the engine retains attribution, share-alike,
noncommercial, and no-derivatives conditions. Creative Commons' official
[licence overview](https://creativecommons.org/share-your-work/use-remix/cc-licenses/)
explains those conditions.

RightsStatements.org markers are statements, not licences. `NoC-US` only
reports a U.S. determination, while `InC-*` indicates copyright. See the
[No Copyright statements](https://rightsstatements.org/page/collection-nc/1.0/?language=en).

## Edition and translation boundaries

A candidate is not an abstract ancient work. It is one concrete digital
edition. Its rights may include:

- the underlying original text;
- a translation;
- editing, annotation, introduction, commentary, or critical apparatus;
- transcription or encoding;
- database or compilation rights;
- the provider's terms and trademarks.

`copyright_author_death_year` means the person whose contribution controls the
candidate edition's relevant term—often the translator for a translation, not
the ancient author.

## Lock implementation

When access permits download but publication is not affirmatively cleared:

- the bytes are stored below `locked/`;
- the file mode is set to `0600`;
- an adjacent `.LOCK.json` says `do_not_publish: true`;
- the corpus and rights records repeat the decision and reasons.

`verify-corpus` fails if a locked file is missing its marker, is readable by
group/other users, is marked publishable, has changed bytes, or has an invalid
checksum.

Removing a lock requires new edition-specific evidence and a new assessment.

