"""MediaWiki Action API adapter for texts and Commons file metadata."""

from datetime import datetime
import json
from typing import Any, Iterable, Mapping

from religious_mythology_resource_hunter.adapters import (
    SourceAdapter,
    source_defaults,
)
from religious_mythology_resource_hunter.catalog import Entity
from religious_mythology_resource_hunter.matching import EntityMatcher
from religious_mythology_resource_hunter.normalization import (
    normalize_space,
    strip_html,
)
from religious_mythology_resource_hunter.plain_text import chunk_text
from religious_mythology_resource_hunter.records import make_record


def _pages(document: Mapping[str, Any]) -> list[Mapping[str, Any]]:
    query = document.get("query", {})
    if not isinstance(query, dict):
        return []
    pages = query.get("pages", {})
    if isinstance(pages, list):
        return [page for page in pages if isinstance(page, dict)]
    if isinstance(pages, dict):
        return [page for page in pages.values() if isinstance(page, dict)]
    return []


def _extended_metadata(page: Mapping[str, Any]) -> dict[str, str]:
    image_info = page.get("imageinfo", [])
    if not isinstance(image_info, list) or not image_info:
        return {}
    first = image_info[0]
    if not isinstance(first, dict):
        return {}
    metadata = first.get("extmetadata", {})
    if not isinstance(metadata, dict):
        return {}
    result: dict[str, str] = {}
    for key, value in metadata.items():
        if isinstance(value, dict):
            raw = value.get("value")
            if raw is None:
                raw = value.get("Value")
        else:
            raw = value
        clean = strip_html(raw)
        if clean:
            result[key.casefold()] = clean
    return result


def _revision_text(page: Mapping[str, Any]) -> str:
    revisions = page.get("revisions", [])
    if not isinstance(revisions, list) or not revisions:
        return ""
    revision = revisions[0]
    if not isinstance(revision, dict):
        return ""
    slots = revision.get("slots")
    if isinstance(slots, dict):
        main = slots.get("main", {})
        if isinstance(main, dict):
            return str(main.get("*") or main.get("content") or "")
    return str(revision.get("*") or revision.get("content") or "")


def _meta(metadata: Mapping[str, str], *keys: str) -> str:
    for key in keys:
        value = metadata.get(key.casefold())
        if value:
            return value
    return ""


class MediaWikiAdapter(SourceAdapter):
    source_family = "mediawiki"

    def parse_sample(
        self,
        payload: bytes,
        *,
        source: Mapping[str, Any],
        entities: Iterable[Entity],
        retrieved_at: datetime,
    ) -> list[dict[str, Any]]:
        del retrieved_at
        document = json.loads(payload.decode("utf-8"))
        if not isinstance(document, dict):
            raise ValueError("MediaWiki response must be a JSON object")
        defaults = source_defaults(source)
        matcher = EntityMatcher(entities)
        records: list[dict[str, Any]] = []
        for page in _pages(document):
            title = normalize_space(page.get("title")) or "Untitled"
            page_id = str(page.get("pageid") or title)
            url = normalize_space(page.get("fullurl"))
            metadata = _extended_metadata(page)
            is_file = bool(page.get("imageinfo")) or int(page.get("ns", 0)) == 6
            if is_file:
                description = (
                    _meta(
                        metadata,
                        "imagedescription",
                        "description",
                        "objectname",
                    )
                    or strip_html(page.get("extract"))
                )
                creator = _meta(
                    metadata, "artist", "author", "credit", "creator"
                )
                date = _meta(
                    metadata, "dateTimeOriginal", "date", "created"
                )
                medium = _meta(metadata, "medium", "technique")
                classification = _meta(
                    metadata, "objecttype", "mime", "mediatype"
                )
                evidence_text = normalize_space(
                    " ".join([title, description, " ".join(metadata.values())])
                )
                excerpt_parts = [f'"{title.removeprefix("File:")}"']
                if creator:
                    excerpt_parts.append(f"— {creator}")
                if date:
                    excerpt_parts.append(date)
                if medium:
                    excerpt_parts.append(medium)
                if classification:
                    excerpt_parts.append(classification)
                if description:
                    excerpt_parts.append(description)
                excerpt = ". ".join(
                    part.rstrip(" .") for part in excerpt_parts if part
                ) + "."
                for match in matcher.find(evidence_text):
                    records.append(
                        make_record(
                            match.entity,
                            match.alias,
                            record_type="museum_object",
                            source_work=str(
                                defaults.get("source_work")
                                or f"{source['name']} file description"
                            ),
                            source_author=str(
                                defaults.get("source_author")
                                or source["name"]
                            ),
                            translator=None,
                            corpus=str(defaults.get("corpus", "museum")),
                            origin=str(
                                defaults.get(
                                    "origin", "museum_catalog_modern"
                                )
                            ),
                            locator=page_id,
                            excerpt=excerpt,
                            optional={
                                "url": url or str(source["endpoint_url"]),
                                "artwork_title": title.removeprefix("File:"),
                                "artwork_date": date,
                                "artwork_medium": medium,
                                "artwork_classification": classification,
                                "match_confidence": (
                                    "high"
                                    if match.alias.casefold()
                                    in title.casefold()
                                    else "medium"
                                ),
                            },
                        )
                    )
                continue

            extract = strip_html(page.get("extract"))
            if not extract:
                extract = normalize_space(_revision_text(page))
            for index, excerpt in enumerate(
                chunk_text(
                    extract,
                    max_words=int(defaults.get("max_words", 260)),
                    overlap_words=int(defaults.get("overlap_words", 35)),
                ),
                1,
            ):
                for match in matcher.find(excerpt):
                    optional = {"url": url} if url else {}
                    records.append(
                        make_record(
                            match.entity,
                            match.alias,
                            record_type=str(
                                defaults.get(
                                    "record_type", "text_excerpt"
                                )
                            ),
                            source_work=str(
                                defaults.get("source_work") or title
                            ),
                            source_author=str(
                                defaults.get(
                                    "source_author", source["name"]
                                )
                            ),
                            translator=defaults.get("translator"),
                            corpus=str(
                                defaults.get("corpus", "wikisource")
                            ),
                            origin=str(
                                defaults.get("origin", "primary_source")
                            ),
                            locator=f"{page_id}#chunk-{index}",
                            excerpt=excerpt,
                            optional=optional,
                        )
                    )
        return records

