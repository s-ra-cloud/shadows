"""Religious and Mythology Resource Hunter."""

__version__ = "0.2.0"
