"""Deterministic alias matching against a figure catalog."""

from dataclasses import dataclass
import re
from typing import Iterable, Optional

from religious_mythology_resource_hunter.catalog import Entity
from religious_mythology_resource_hunter.normalization import normalized_lookup


@dataclass(frozen=True)
class EntityMatch:
    entity: Entity
    alias: str


class EntityMatcher:
    """Match canonical long names loosely and alternative aliases exactly.

    Short canonical names and all alternative aliases are case-sensitive. This
    reduces false positives for Ra, Nut, Pan, Dis, Fortune, Night, and similar
    strings while canonical names longer than three characters remain
    case-insensitive.
    """

    def __init__(self, entities: Iterable[Entity]) -> None:
        self._insensitive: dict[str, list[tuple[Entity, str]]] = {}
        self._sensitive: dict[str, list[tuple[Entity, str]]] = {}
        for entity in entities:
            for alias in entity.aliases:
                if (
                    len(alias) > 3
                    and normalized_lookup(alias)
                    == normalized_lookup(entity.name)
                ):
                    self._insensitive.setdefault(
                        normalized_lookup(alias), []
                    ).append((entity, alias))
                else:
                    self._sensitive.setdefault(alias, []).append((entity, alias))
        self._insensitive_pattern = self._compile(
            self._insensitive, ignore_case=True
        )
        self._sensitive_pattern = self._compile(
            self._sensitive, ignore_case=False
        )

    @staticmethod
    def _compile(
        aliases: dict[str, list[tuple[Entity, str]]],
        *,
        ignore_case: bool,
    ) -> Optional[re.Pattern[str]]:
        if not aliases:
            return None
        values = []
        for values_for_alias in aliases.values():
            values.append(values_for_alias[0][1])
        alternatives = "|".join(
            re.escape(alias) for alias in sorted(values, key=len, reverse=True)
        )
        flags = re.IGNORECASE if ignore_case else 0
        return re.compile(rf"(?<!\w)(?:{alternatives})(?!\w)", flags)

    def find(self, text: str) -> list[EntityMatch]:
        found: list[EntityMatch] = []
        seen: set[tuple[str, str]] = set()
        if self._insensitive_pattern:
            for result in self._insensitive_pattern.finditer(text):
                key = normalized_lookup(result.group(0))
                for entity, alias in self._insensitive.get(key, []):
                    entity_key = (
                        entity.name.casefold(),
                        entity.tradition.casefold(),
                    )
                    if entity_key not in seen:
                        seen.add(entity_key)
                        found.append(EntityMatch(entity, result.group(0)))
        if self._sensitive_pattern:
            for result in self._sensitive_pattern.finditer(text):
                for entity, alias in self._sensitive.get(result.group(0), []):
                    entity_key = (
                        entity.name.casefold(),
                        entity.tradition.casefold(),
                    )
                    if entity_key not in seen:
                        seen.add(entity_key)
                        found.append(EntityMatch(entity, alias))
        return found
