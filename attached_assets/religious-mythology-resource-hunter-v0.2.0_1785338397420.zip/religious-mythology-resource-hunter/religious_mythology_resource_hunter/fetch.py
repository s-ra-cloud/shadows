"""Conservative one-request transport for reviewed registry sources."""

from typing import Any, Mapping
from urllib.parse import urlparse
from urllib.request import Request, urlopen
from urllib.robotparser import RobotFileParser


DEFAULT_USER_AGENT = (
    "ReligiousMythologyResourceHunter/0.1 "
    "(research collector; contact configured by operator)"
)


def _allowed_host(url: str, source: Mapping[str, Any]) -> bool:
    target = (urlparse(url).hostname or "").casefold()
    endpoint = (
        urlparse(str(source["endpoint_url"])).hostname or ""
    ).casefold()
    allowed = source.get("allowed_hosts", [endpoint])
    return any(
        target == str(host).casefold()
        or target.endswith("." + str(host).casefold())
        for host in allowed
    )


def fetch_payload(
    url: str,
    source: Mapping[str, Any],
    *,
    user_agent: str = DEFAULT_USER_AGENT,
    timeout: float = 30.0,
    max_bytes: int = 25_000_000,
) -> tuple[bytes, str]:
    """Fetch one allowed payload after a robots check."""
    if not _allowed_host(url, source):
        raise ValueError("URL host is not allowed by the source definition")
    access = source.get("access", {})
    if access.get("review_status") == "blocked":
        raise ValueError("source access review is blocked")
    robots_url = access.get("robots_url")
    if robots_url:
        parser = RobotFileParser()
        parser.set_url(str(robots_url))
        parser.read()
        if not parser.can_fetch(user_agent, url):
            raise PermissionError(f"robots policy disallows retrieval: {url}")
    request = Request(
        url,
        headers={
            "Accept": "application/json, application/xml, text/xml, text/plain",
            "User-Agent": user_agent,
        },
    )
    with urlopen(request, timeout=timeout) as response:
        payload = response.read(max_bytes + 1)
        content_type = response.headers.get_content_type()
    if len(payload) > max_bytes:
        raise ValueError(f"response exceeds {max_bytes} bytes")
    return payload, content_type

