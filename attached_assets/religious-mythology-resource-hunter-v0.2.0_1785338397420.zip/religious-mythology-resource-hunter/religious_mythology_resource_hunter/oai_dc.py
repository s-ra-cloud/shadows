"""OAI-PMH Dublin Core adapter for museum and library descriptions."""

from datetime import datetime
from typing import Any, Iterable, Mapping, Optional
import xml.etree.ElementTree as ET

from religious_mythology_resource_hunter.adapters import (
    SourceAdapter,
    source_defaults,
)
from religious_mythology_resource_hunter.catalog import Entity
from religious_mythology_resource_hunter.matching import EntityMatcher
from religious_mythology_resource_hunter.normalization import normalize_space
from religious_mythology_resource_hunter.records import make_record


def _local(element: ET.Element) -> str:
    return element.tag.rsplit("}", 1)[-1]


def _metadata_element(record: ET.Element) -> Optional[ET.Element]:
    for element in record.iter():
        if _local(element) == "metadata":
            return element
    return None


def _values(metadata: ET.Element) -> dict[str, list[str]]:
    values: dict[str, list[str]] = {}
    for element in metadata.iter():
        if element is metadata:
            continue
        value = normalize_space(" ".join(element.itertext()))
        if value:
            values.setdefault(_local(element).casefold(), []).append(value)
    return values


def _first(values: Mapping[str, list[str]], key: str) -> str:
    items = values.get(key, [])
    return items[0] if items else ""


def _record_identifier(record: ET.Element) -> str:
    for element in record.iter():
        if _local(element) == "header":
            for child in element.iter():
                if _local(child) == "identifier":
                    return normalize_space(" ".join(child.itertext()))
    return ""


class OaiDcAdapter(SourceAdapter):
    source_family = "oai_dc"

    def parse_sample(
        self,
        payload: bytes,
        *,
        source: Mapping[str, Any],
        entities: Iterable[Entity],
        retrieved_at: datetime,
    ) -> list[dict[str, Any]]:
        del retrieved_at
        root = ET.fromstring(payload)
        defaults = source_defaults(source)
        matcher = EntityMatcher(entities)
        records: list[dict[str, Any]] = []
        candidates = [
            element for element in root.iter() if _local(element) == "record"
        ]
        if _local(root) == "record":
            candidates = [root]
        for source_record in candidates:
            metadata_element = _metadata_element(source_record)
            if metadata_element is None:
                continue
            values = _values(metadata_element)
            title = _first(values, "title") or "Untitled"
            descriptions = values.get("description", [])
            subjects = values.get("subject", [])
            creators = values.get("creator", [])
            dates = values.get("date", [])
            formats = values.get("format", [])
            types = values.get("type", [])
            identifiers = values.get("identifier", [])
            source_native_id = _record_identifier(source_record)
            url = next(
                (
                    identifier
                    for identifier in identifiers
                    if identifier.startswith(("http://", "https://"))
                ),
                str(source["endpoint_url"]),
            )
            evidence_text = normalize_space(
                " ".join([title] + descriptions + subjects)
            )
            matches = matcher.find(evidence_text)
            record_type = str(
                defaults.get("record_type", "museum_object")
            )
            creator = "; ".join(creators)
            date = "; ".join(dates)
            medium = "; ".join(formats)
            classification = "; ".join(types)
            if record_type == "museum_object":
                parts = [f'"{title}"']
                if creator:
                    parts.append(f"— {creator}")
                if date:
                    parts.append(date)
                if medium:
                    parts.append(medium)
                if classification:
                    parts.append(classification)
                parts.extend(descriptions)
                excerpt = ". ".join(
                    part.rstrip(" .") for part in parts if part
                ) + "."
            else:
                excerpt = evidence_text
            for match in matches:
                optional = {}
                if record_type == "museum_object":
                    optional = {
                        "url": url,
                        "artwork_title": title,
                        "artwork_date": date,
                        "artwork_medium": medium,
                        "artwork_classification": classification,
                        "match_confidence": (
                            "high"
                            if match.alias.casefold() in title.casefold()
                            else "medium"
                        ),
                    }
                elif url:
                    optional["url"] = url
                records.append(
                    make_record(
                        match.entity,
                        match.alias,
                        record_type=record_type,
                        source_work=str(
                            defaults.get("source_work")
                            or f"{source['name']} collection record"
                        ),
                        source_author=str(
                            defaults.get("source_author") or source["name"]
                        ),
                        translator=defaults.get("translator"),
                        corpus=str(defaults.get("corpus", "museum")),
                        origin=str(
                            defaults.get(
                                "origin", "museum_catalog_modern"
                            )
                        ),
                        locator=source_native_id or url,
                        excerpt=excerpt,
                        optional=optional,
                    )
                )
        return records

