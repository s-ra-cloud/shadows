"""Small deterministic text-normalization helpers."""

from html import unescape
from html.parser import HTMLParser
import re
import unicodedata


class _TextExtractor(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.parts: list[str] = []

    def handle_data(self, data: str) -> None:
        self.parts.append(data)


def normalize_space(value: object) -> str:
    """Return NFC text with repeated whitespace collapsed."""
    if value is None:
        return ""
    return " ".join(unicodedata.normalize("NFC", str(value)).split())


def strip_html(value: object) -> str:
    """Convert a small HTML fragment to normalized plain text."""
    if value is None:
        return ""
    parser = _TextExtractor()
    parser.feed(unescape(str(value)))
    parser.close()
    return normalize_space(" ".join(parser.parts))


def word_count(value: str) -> int:
    """Use the same whitespace-token convention as the reference JSONL."""
    return len(value.split())


def normalized_lookup(value: str) -> str:
    """Normalize an alias for case-insensitive lookup."""
    return unicodedata.normalize("NFKC", normalize_space(value)).casefold()


def slug(value: str) -> str:
    """Create a conservative ASCII identifier component."""
    ascii_value = unicodedata.normalize("NFKD", value).encode(
        "ascii", "ignore"
    ).decode("ascii")
    result = re.sub(r"[^a-z0-9]+", "-", ascii_value.casefold()).strip("-")
    return result or "unknown"

