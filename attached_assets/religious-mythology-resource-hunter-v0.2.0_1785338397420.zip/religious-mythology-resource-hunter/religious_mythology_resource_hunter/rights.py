"""Conservative, evidence-backed copyright and reuse assessment."""

from datetime import datetime
import re
from typing import Any, Mapping, Optional


UNLOCKED_STATUSES = {"public_domain", "open_license"}


def _joined_rights_text(
    candidate: Mapping[str, Any], embedded_notice: str
) -> str:
    rights = candidate.get("rights", {})
    values = [
        rights.get("statement"),
        rights.get("license"),
        rights.get("license_url"),
        rights.get("rights_url"),
        embedded_notice,
    ]
    return " ".join(str(value) for value in values if value).casefold()


def _territory_covers(
    territories: list[str], target_jurisdiction: str
) -> bool:
    normalized = {item.upper() for item in territories}
    target = target_jurisdiction.upper()
    if "WORLDWIDE" in normalized or target in normalized:
        return True
    return target == "FR" and "EU" in normalized


def _cc_assessment(text: str) -> Optional[dict[str, Any]]:
    if (
        "creativecommons.org/publicdomain/zero" in text
        or re.search(r"\bcc0(?:\s|/|$)", text)
    ):
        return {
            "status": "public_domain",
            "license": "CC0",
            "translation_allowed": True,
            "obligations": [],
        }
    if (
        "creativecommons.org/publicdomain/mark" in text
        or "public domain mark" in text
    ):
        return {
            "status": "public_domain",
            "license": "Public Domain Mark",
            "translation_allowed": True,
            "obligations": [],
        }
    if "creative commons" not in text and "creativecommons.org/licenses/" not in text:
        return None
    no_derivatives = (
        "/by-nd/" in text
        or "/by-nc-nd/" in text
        or "cc by-nd" in text
        or "cc by-nc-nd" in text
        or "no derivatives" in text
        or "noderivatives" in text
    )
    noncommercial = (
        "/by-nc" in text
        or "cc by-nc" in text
        or "noncommercial" in text
    )
    share_alike = "/by-sa/" in text or "cc by-sa" in text or "sharealike" in text
    if no_derivatives or noncommercial:
        obligations = ["attribution"]
        if no_derivatives:
            obligations.append("no_derivatives")
        if noncommercial:
            obligations.append("noncommercial_only")
        if share_alike:
            obligations.append("share_alike")
        return {
            "status": "restricted_license",
            "license": "Creative Commons restricted licence",
            "translation_allowed": not no_derivatives,
            "obligations": obligations,
        }
    if share_alike:
        return {
            "status": "open_license",
            "license": "CC BY-SA",
            "translation_allowed": True,
            "obligations": ["attribution", "share_alike"],
        }
    if "/by/" in text or re.search(r"\bcc by(?:\s|$)", text):
        return {
            "status": "open_license",
            "license": "CC BY",
            "translation_allowed": True,
            "obligations": ["attribution"],
        }
    return None


def _standard_rights_statement(text: str) -> Optional[dict[str, Any]]:
    if "rightsstatements.org/vocab/inc" in text:
        return {
            "status": "copyrighted",
            "translation_allowed": False,
            "obligations": ["do_not_publish_without_permission"],
        }
    if (
        "rightsstatements.org/vocab/noc-nc" in text
        or "rightsstatements.org/vocab/noc-oklr" in text
        or "rightsstatements.org/vocab/noc-cr" in text
    ):
        return {
            "status": "restricted_license",
            "translation_allowed": False,
            "obligations": ["review_known_restrictions"],
        }
    if "rightsstatements.org/vocab/noc-us" in text:
        return {
            "status": "public_domain_jurisdictional",
            "translation_allowed": True,
            "obligations": ["public_domain_determination_is_us_only"],
            "territories": ["US"],
        }
    return None


def _result(
    *,
    status: str,
    confidence: str,
    basis: str,
    target_jurisdiction: str,
    territories: list[str],
    statement: str,
    license_name: Optional[str],
    rights_url: Optional[str],
    license_url: Optional[str],
    translation_allowed: bool,
    obligations: list[str],
    reasons: list[str],
    assessed_at: datetime,
    unlock_likely: bool,
) -> dict[str, Any]:
    territory_covered = _territory_covers(
        territories, target_jurisdiction
    )
    explicitly_free = status in UNLOCKED_STATUSES
    likely_unlocked = status == "public_domain_likely" and unlock_likely
    publication_allowed = (
        (explicitly_free and territory_covered) or likely_unlocked
    )
    if status == "open_license":
        publication_allowed = True
        territory_covered = True
    locked = not publication_allowed
    review_required = confidence != "high" or locked
    return {
        "status": status,
        "confidence": confidence,
        "basis": basis,
        "target_jurisdiction": target_jurisdiction,
        "territories": territories,
        "territory_covered": territory_covered,
        "statement": statement,
        "license": license_name,
        "rights_url": rights_url,
        "license_url": license_url,
        "publication_allowed": publication_allowed,
        "translation_allowed": translation_allowed and publication_allowed,
        "locked": locked,
        "do_not_publish": locked,
        "review_required": review_required,
        "obligations": obligations,
        "reasons": reasons,
        "assessed_at": assessed_at.isoformat(),
        "not_legal_advice": True,
    }


def assess_rights(
    candidate: Mapping[str, Any],
    policy: Mapping[str, Any],
    *,
    embedded_notice: str = "",
    assessed_at: datetime,
) -> dict[str, Any]:
    """Assess one edition; unknown or jurisdiction-mismatched means locked."""
    rights = candidate.get("rights", {})
    statement = str(rights.get("statement") or "")
    license_name = rights.get("license")
    license_url = rights.get("license_url")
    rights_url = rights.get("rights_url")
    territories = [
        str(item).upper() for item in rights.get("territories", [])
    ]
    target = str(policy["target_jurisdiction"]).upper()
    unlock_likely = bool(policy["unlock_likely_public_domain"])
    text = _joined_rights_text(candidate, embedded_notice)
    basis = str(rights.get("basis") or "unknown")
    claim = str(rights.get("status_claim") or "unknown")

    cc = _cc_assessment(text)
    strong_copyright_marker = (
        claim == "copyrighted"
        or "all rights reserved" in text
        or "posted with permission of the copyright holder" in text
        or "not in the public domain" in text
        or "not public domain" in text
    )
    if cc and strong_copyright_marker:
        return _result(
            status="conflicting",
            confidence="low",
            basis=basis,
            target_jurisdiction=target,
            territories=territories,
            statement=statement,
            license_name=license_name,
            rights_url=rights_url,
            license_url=license_url,
            translation_allowed=False,
            obligations=["resolve_conflicting_rights_evidence"],
            reasons=[
                "open licence marker conflicts with restrictive copyright evidence"
            ],
            assessed_at=assessed_at,
            unlock_likely=unlock_likely,
        )
    if cc:
        cc_territories = ["WORLDWIDE"]
        return _result(
            status=cc["status"],
            confidence="high",
            basis=basis,
            target_jurisdiction=target,
            territories=cc_territories,
            statement=statement,
            license_name=license_name or cc["license"],
            rights_url=rights_url,
            license_url=license_url,
            translation_allowed=cc["translation_allowed"],
            obligations=cc["obligations"],
            reasons=["standardized Creative Commons marker"],
            assessed_at=assessed_at,
            unlock_likely=unlock_likely,
        )

    standard = _standard_rights_statement(text)
    if standard:
        return _result(
            status=standard["status"],
            confidence="high",
            basis=basis,
            target_jurisdiction=target,
            territories=standard.get("territories", territories),
            statement=statement,
            license_name=license_name,
            rights_url=rights_url,
            license_url=license_url,
            translation_allowed=standard["translation_allowed"],
            obligations=standard["obligations"],
            reasons=["standardized RightsStatements.org marker"],
            assessed_at=assessed_at,
            unlock_likely=unlock_likely,
        )

    strong_restriction = (
        claim == "copyrighted"
        or "all rights reserved" in text
        or "posted with permission of the copyright holder" in text
        or "one of the few individual works restricted by copyright" in text
        or "not in the public domain" in text
        or "not public domain" in text
    )
    if strong_restriction:
        return _result(
            status="copyrighted",
            confidence="high",
            basis=basis,
            target_jurisdiction=target,
            territories=territories,
            statement=statement,
            license_name=license_name,
            rights_url=rights_url,
            license_url=license_url,
            translation_allowed=False,
            obligations=["do_not_publish_without_permission"],
            reasons=["explicit copyright restriction"],
            assessed_at=assessed_at,
            unlock_likely=unlock_likely,
        )

    us_only_marker = (
        "not restricted by u.s. copyright law" in text
        or "public domain in the united states" in text
        or "not protected by copyright in the united states" in text
    )
    if us_only_marker:
        return _result(
            status=(
                "public_domain"
                if target == "US"
                else "public_domain_jurisdictional"
            ),
            confidence="high",
            basis=basis,
            target_jurisdiction=target,
            territories=["US"],
            statement=statement,
            license_name=license_name,
            rights_url=rights_url,
            license_url=license_url,
            translation_allowed=True,
            obligations=["verify_status_outside_the_united_states"],
            reasons=["explicit United States-only public-domain statement"],
            assessed_at=assessed_at,
            unlock_likely=unlock_likely,
        )

    copyright_markers = (
        "all rights reserved",
        "restricted by copyright",
        "protected by copyright",
        "copyrighted work",
        "posted with permission of the copyright holder",
        "not in the public domain",
        "not public domain",
    )
    if any(
        marker in text for marker in copyright_markers
    ):
        return _result(
            status="copyrighted",
            confidence="high",
            basis=basis,
            target_jurisdiction=target,
            territories=territories,
            statement=statement,
            license_name=license_name,
            rights_url=rights_url,
            license_url=license_url,
            translation_allowed=False,
            obligations=["do_not_publish_without_permission"],
            reasons=["explicit copyright restriction"],
            assessed_at=assessed_at,
            unlock_likely=unlock_likely,
        )

    public_domain_marker = (
        claim == "public_domain"
        or "public domain" in text
        or "no known copyright" in text
    )
    if public_domain_marker:
        effective_territories = territories or ["UNSPECIFIED"]
        status = (
            "public_domain"
            if _territory_covers(effective_territories, target)
            else "public_domain_jurisdictional"
        )
        return _result(
            status=status,
            confidence="high" if territories else "medium",
            basis=basis,
            target_jurisdiction=target,
            territories=effective_territories,
            statement=statement,
            license_name=license_name,
            rights_url=rights_url,
            license_url=license_url,
            translation_allowed=True,
            obligations=(
                []
                if status == "public_domain"
                else ["verify_target_jurisdiction"]
            ),
            reasons=["explicit public-domain claim"],
            assessed_at=assessed_at,
            unlock_likely=unlock_likely,
        )

    if claim == "open_license":
        return _result(
            status="unknown",
            confidence="low",
            basis=basis,
            target_jurisdiction=target,
            territories=territories,
            statement=statement,
            license_name=license_name,
            rights_url=rights_url,
            license_url=license_url,
            translation_allowed=False,
            obligations=["identify_exact_open_license"],
            reasons=["open-license claim lacks a recognized licence marker"],
            assessed_at=assessed_at,
            unlock_likely=unlock_likely,
        )

    death_year = candidate.get("copyright_author_death_year")
    current_year = int(policy["current_year"])
    if (
        target in {"FR", "EU"}
        and isinstance(death_year, int)
        and death_year <= current_year - 71
    ):
        return _result(
            status="public_domain_likely",
            confidence="medium",
            basis="term_heuristic",
            target_jurisdiction=target,
            territories=[target],
            statement=statement,
            license_name=license_name,
            rights_url=rights_url,
            license_url=license_url,
            translation_allowed=True,
            obligations=["human_review_of_authorship_and_term_exceptions"],
            reasons=[
                "edition copyright author death year exceeds life-plus-70"
            ],
            assessed_at=assessed_at,
            unlock_likely=unlock_likely,
        )

    publication_year = candidate.get("publication_year")
    if (
        target == "US"
        and isinstance(publication_year, int)
        and publication_year <= current_year - 96
    ):
        return _result(
            status="public_domain_likely",
            confidence="medium",
            basis="term_heuristic",
            target_jurisdiction=target,
            territories=["US"],
            statement=statement,
            license_name=license_name,
            rights_url=rights_url,
            license_url=license_url,
            translation_allowed=True,
            obligations=["human_review_of_us_publication_history"],
            reasons=["publication date exceeds conservative 95-year term"],
            assessed_at=assessed_at,
            unlock_likely=unlock_likely,
        )

    return _result(
        status="unknown",
        confidence="low",
        basis=basis,
        target_jurisdiction=target,
        territories=territories,
        statement=statement,
        license_name=license_name,
        rights_url=rights_url,
        license_url=license_url,
        translation_allowed=False,
        obligations=["rights_review_required"],
        reasons=["no conclusive rights evidence"],
        assessed_at=assessed_at,
        unlock_likely=unlock_likely,
    )


def extract_embedded_notice(payload: bytes, file_format: str) -> str:
    """Return only boundary text likely to contain an edition rights notice."""
    if file_format not in {"txt", "tei_xml", "xml", "html", "json"}:
        return ""
    boundary = payload[:65536]
    if len(payload) > 65536:
        boundary += b"\n" + payload[-65536:]
    return boundary.decode("utf-8", errors="ignore")
