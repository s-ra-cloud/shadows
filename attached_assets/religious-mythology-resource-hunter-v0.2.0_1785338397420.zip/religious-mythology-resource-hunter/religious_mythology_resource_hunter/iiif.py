"""IIIF Presentation 2.x/3.x manifest adapter."""

from datetime import datetime
import json
from typing import Any, Iterable, Mapping

from religious_mythology_resource_hunter.adapters import (
    SourceAdapter,
    source_defaults,
)
from religious_mythology_resource_hunter.catalog import Entity
from religious_mythology_resource_hunter.matching import EntityMatcher
from religious_mythology_resource_hunter.normalization import (
    normalize_space,
    strip_html,
)
from religious_mythology_resource_hunter.records import make_record


def language_text(value: object) -> str:
    if isinstance(value, str):
        return strip_html(value)
    if isinstance(value, list):
        return normalize_space(
            " ".join(language_text(item) for item in value if language_text(item))
        )
    if isinstance(value, dict):
        if "@value" in value:
            return strip_html(value["@value"])
        values = []
        for key, item in value.items():
            if key.startswith("@"):
                continue
            item_text = language_text(item)
            if item_text:
                values.append(item_text)
        return normalize_space(" ".join(values))
    return ""


def _metadata(manifest: Mapping[str, Any]) -> dict[str, str]:
    result: dict[str, str] = {}
    for item in manifest.get("metadata", []) or []:
        if not isinstance(item, dict):
            continue
        label = language_text(item.get("label")).casefold()
        value = language_text(item.get("value"))
        if label and value:
            result[label] = value
    return result


def _metadata_value(metadata: Mapping[str, str], *names: str) -> str:
    for name in names:
        name_key = name.casefold()
        for key, value in metadata.items():
            if key == name_key or name_key in key:
                return value
    return ""


def _linked_url(value: object) -> str:
    if isinstance(value, str):
        return value
    if isinstance(value, dict):
        return str(value.get("id") or value.get("@id") or "")
    if isinstance(value, list):
        for item in value:
            url = _linked_url(item)
            if url:
                return url
    return ""


def _agent_label(value: object) -> str:
    if isinstance(value, str):
        return strip_html(value)
    if isinstance(value, dict):
        return language_text(value.get("label") or value.get("name"))
    if isinstance(value, list):
        return normalize_space(
            " ".join(_agent_label(item) for item in value if _agent_label(item))
        )
    return ""


class IiifAdapter(SourceAdapter):
    source_family = "iiif"

    def parse_sample(
        self,
        payload: bytes,
        *,
        source: Mapping[str, Any],
        entities: Iterable[Entity],
        retrieved_at: datetime,
    ) -> list[dict[str, Any]]:
        del retrieved_at
        manifest = json.loads(payload.decode("utf-8"))
        if not isinstance(manifest, dict):
            raise ValueError("IIIF manifest must be a JSON object")
        defaults = source_defaults(source)
        metadata = _metadata(manifest)
        title = (
            language_text(manifest.get("label"))
            or _metadata_value(metadata, "title", "object name")
            or "Untitled"
        )
        description = language_text(
            manifest.get("summary") or manifest.get("description")
        ) or _metadata_value(metadata, "description")
        creator = _metadata_value(
            metadata, "creator", "artist", "maker", "author"
        )
        date = _metadata_value(metadata, "date", "created")
        medium = _metadata_value(
            metadata, "medium", "material", "technique", "format"
        )
        classification = _metadata_value(
            metadata, "classification", "object type", "type"
        )
        provider = _agent_label(
            manifest.get("provider") or manifest.get("attribution")
        )
        institution = (
            str(defaults.get("source_author"))
            if defaults.get("source_author")
            else provider or str(source["name"])
        )
        parts = [f'"{title}"']
        if creator:
            parts.append(f"— {creator}")
        if date:
            parts.append(date)
        if medium:
            parts.append(medium)
        if classification:
            parts.append(classification)
        if description:
            parts.append(description)
        if institution:
            parts.append(institution)
        excerpt = ". ".join(part.rstrip(" .") for part in parts if part) + "."
        matcher = EntityMatcher(entities)
        matches = matcher.find(
            " ".join([title, description, " ".join(metadata.values())])
        )
        manifest_id = str(manifest.get("id") or manifest.get("@id") or "")
        url = (
            _linked_url(manifest.get("homepage"))
            or _linked_url(manifest.get("related"))
            or manifest_id
            or str(source["endpoint_url"])
        )
        records = []
        for match in matches:
            confidence = (
                "high"
                if match.alias.casefold() in title.casefold()
                else "medium"
            )
            records.append(
                make_record(
                    match.entity,
                    match.alias,
                    record_type="museum_object",
                    source_work=str(
                        defaults.get("source_work")
                        or f"{source['name']} collection record"
                    ),
                    source_author=institution,
                    translator=None,
                    corpus=str(defaults.get("corpus", "museum")),
                    origin=str(
                        defaults.get("origin", "museum_catalog_modern")
                    ),
                    locator=manifest_id or url,
                    excerpt=excerpt,
                    optional={
                        "url": url,
                        "artwork_title": title,
                        "artwork_date": date,
                        "artwork_medium": medium,
                        "artwork_classification": classification,
                        "match_confidence": confidence,
                    },
                )
            )
        return records
