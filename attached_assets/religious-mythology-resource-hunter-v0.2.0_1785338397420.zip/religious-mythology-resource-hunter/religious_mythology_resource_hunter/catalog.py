"""Entity-catalog loading, including SHADOWS export compatibility."""

from dataclasses import dataclass
import json
from pathlib import Path
from typing import Any, Iterable, Mapping

from religious_mythology_resource_hunter.normalization import normalize_space


# Confirmed noise in the supplied reference corpus. This is deliberately a
# narrow, auditable exception rather than a language-wide stop-word list.
REJECTED_IMPORTED_ALIAS_PAIRS = {("hera", "here")}


@dataclass(frozen=True)
class Entity:
    """A religious or mythological figure and its matchable names."""

    name: str
    tradition: str
    gender: str
    aliases: tuple[str, ...]


def _normalized_gender(value: object) -> str:
    gender = normalize_space(value).casefold()
    return gender or "unknown"


def _string_aliases(value: object) -> list[str]:
    if isinstance(value, str):
        return [part.strip() for part in value.split("|") if part.strip()]
    if isinstance(value, list):
        return [
            normalize_space(item)
            for item in value
            if isinstance(item, str) and normalize_space(item)
        ]
    return []


def entity_from_mapping(item: Mapping[str, Any]) -> Entity:
    name = normalize_space(item.get("name") or item.get("deity"))
    if not name:
        raise ValueError("catalog entity is missing name/deity")
    tradition = normalize_space(item.get("tradition")) or "Unknown"
    aliases = [name]
    aliases.extend(_string_aliases(item.get("aliases")))
    aliases.extend(_string_aliases(item.get("alternativeNames")))
    aliases.extend(_string_aliases(item.get("alternative_names")))
    aliases = list(dict.fromkeys(normalize_space(alias) for alias in aliases if alias))
    return Entity(
        name=name,
        tradition=tradition,
        gender=_normalized_gender(item.get("gender")),
        aliases=tuple(aliases),
    )


def entities_from_document(document: object) -> list[Entity]:
    """Read a SHADOWS export, catalog document, or simple list."""
    if isinstance(document, dict):
        if isinstance(document.get("nodes"), list):
            rows = document["nodes"]
        elif isinstance(document.get("entities"), list):
            rows = document["entities"]
        else:
            raise ValueError("catalog object must contain nodes or entities")
    elif isinstance(document, list):
        rows = document
    else:
        raise ValueError("catalog must be a JSON object or array")

    entities: list[Entity] = []
    for row in rows:
        if not isinstance(row, dict):
            continue
        try:
            entity = entity_from_mapping(row)
        except ValueError:
            continue
        entities.append(entity)
    return merge_entities(entities)


def entities_from_jsonl(path: Path) -> list[Entity]:
    """Build catalog entities and aliases from compatible resource JSONL."""
    grouped: dict[tuple[str, str], dict[str, Any]] = {}
    with path.open(encoding="utf-8") as file:
        for line_number, line in enumerate(file, 1):
            if not line.strip():
                continue
            value = json.loads(line)
            if not isinstance(value, dict):
                raise ValueError(f"{path}:{line_number}: record is not an object")
            name = normalize_space(value.get("deity"))
            tradition = normalize_space(value.get("tradition")) or "Unknown"
            if not name:
                continue
            key = (name.casefold(), tradition.casefold())
            group = grouped.setdefault(
                key,
                {
                    "name": name,
                    "tradition": tradition,
                    "gender": value.get("gender"),
                    "aliases": [],
                },
            )
            alias = normalize_space(value.get("matched_alias"))
            pair = (name.casefold(), alias.casefold())
            if alias and pair not in REJECTED_IMPORTED_ALIAS_PAIRS:
                group["aliases"].append(alias)
    return [entity_from_mapping(item) for item in grouped.values()]


def merge_entities(entities: Iterable[Entity]) -> list[Entity]:
    """Merge duplicate name/tradition entries while retaining every alias."""
    grouped: dict[tuple[str, str], dict[str, Any]] = {}
    order: list[tuple[str, str]] = []
    for entity in entities:
        key = (entity.name.casefold(), entity.tradition.casefold())
        if key not in grouped:
            order.append(key)
            grouped[key] = {
                "name": entity.name,
                "tradition": entity.tradition,
                "gender": entity.gender,
                "aliases": list(entity.aliases),
            }
        else:
            grouped[key]["aliases"].extend(entity.aliases)
            if (
                grouped[key]["gender"] == "unknown"
                and entity.gender != "unknown"
            ):
                grouped[key]["gender"] = entity.gender
    return [entity_from_mapping(grouped[key]) for key in order]


def load_catalog(path: Path) -> list[Entity]:
    if path.suffix.casefold() == ".jsonl":
        return entities_from_jsonl(path)
    with path.open(encoding="utf-8") as file:
        return entities_from_document(json.load(file))


def catalog_document(entities: Iterable[Entity]) -> dict[str, object]:
    return {
        "schema_version": "1.0.0",
        "entities": [
            {
                "name": entity.name,
                "tradition": entity.tradition,
                "gender": entity.gender,
                "aliases": list(entity.aliases),
            }
            for entity in entities
        ],
    }


def write_catalog(path: Path, entities: Iterable[Entity]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as file:
        json.dump(
            catalog_document(entities),
            file,
            ensure_ascii=False,
            indent=2,
        )
        file.write("\n")
