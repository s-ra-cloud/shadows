"""Adapter for UTF-8 plain-text transcriptions."""

from datetime import datetime
import re
from typing import Any, Iterable, Mapping

from religious_mythology_resource_hunter.adapters import (
    SourceAdapter,
    source_defaults,
)
from religious_mythology_resource_hunter.catalog import Entity
from religious_mythology_resource_hunter.matching import EntityMatcher
from religious_mythology_resource_hunter.normalization import normalize_space
from religious_mythology_resource_hunter.records import make_record


def chunk_text(
    text: str,
    *,
    max_words: int = 260,
    overlap_words: int = 35,
) -> list[str]:
    """Split prose into bounded, paragraph-aware evidence excerpts."""
    paragraphs = [
        normalize_space(part)
        for part in re.split(r"\n\s*\n", text)
        if normalize_space(part)
    ]
    chunks: list[str] = []
    for paragraph in paragraphs:
        words = paragraph.split()
        if len(words) <= max_words:
            chunks.append(paragraph)
            continue
        step = max(1, max_words - overlap_words)
        for start in range(0, len(words), step):
            chunk = words[start : start + max_words]
            if not chunk:
                break
            chunks.append(" ".join(chunk))
            if start + max_words >= len(words):
                break
    return chunks


class PlainTextAdapter(SourceAdapter):
    source_family = "plain_text"

    def parse_sample(
        self,
        payload: bytes,
        *,
        source: Mapping[str, Any],
        entities: Iterable[Entity],
        retrieved_at: datetime,
    ) -> list[dict[str, Any]]:
        del retrieved_at
        defaults = source_defaults(source)
        encoding = str(defaults.get("encoding", "utf-8"))
        text = payload.decode(encoding)
        matcher = EntityMatcher(entities)
        max_words = int(defaults.get("max_words", 260))
        overlap_words = int(defaults.get("overlap_words", 35))
        base_locator = str(
            defaults.get("locator") or source.get("endpoint_url") or ""
        )
        optional_defaults = {
            key: defaults[key]
            for key in (
                "excerpt_original",
                "original_language",
                "translation_method",
                "translator_note",
                "url",
            )
            if key in defaults
        }
        records: list[dict[str, Any]] = []
        for index, excerpt in enumerate(
            chunk_text(
                text,
                max_words=max_words,
                overlap_words=overlap_words,
            ),
            1,
        ):
            locator = f"{base_locator}#chunk-{index}"
            for match in matcher.find(excerpt):
                records.append(
                    make_record(
                        match.entity,
                        match.alias,
                        record_type=str(
                            defaults.get("record_type", "text_excerpt")
                        ),
                        source_work=str(
                            defaults.get("source_work") or source["name"]
                        ),
                        source_author=str(
                            defaults.get("source_author", "Unknown")
                        ),
                        translator=defaults.get("translator"),
                        corpus=str(defaults.get("corpus", "unknown")),
                        origin=str(
                            defaults.get("origin", "primary_source")
                        ),
                        locator=locator,
                        excerpt=excerpt,
                        optional=optional_defaults,
                    )
                )
        return records

