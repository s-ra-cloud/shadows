"""TEI P5 XML adapter for primary and translated texts."""

from datetime import datetime
from typing import Any, Iterable, Mapping, Optional
import xml.etree.ElementTree as ET

from religious_mythology_resource_hunter.adapters import (
    SourceAdapter,
    source_defaults,
)
from religious_mythology_resource_hunter.catalog import Entity
from religious_mythology_resource_hunter.matching import EntityMatcher
from religious_mythology_resource_hunter.normalization import normalize_space
from religious_mythology_resource_hunter.records import make_record


XML_ID = "{http://www.w3.org/XML/1998/namespace}id"
XML_LANG = "{http://www.w3.org/XML/1998/namespace}lang"


def _local_name(element: ET.Element) -> str:
    return element.tag.rsplit("}", 1)[-1]


def _text(element: Optional[ET.Element]) -> str:
    if element is None:
        return ""
    return normalize_space(" ".join(element.itertext()))


def _first_descendant(
    parent: Optional[ET.Element], names: set[str]
) -> Optional[ET.Element]:
    if parent is None:
        return None
    for element in parent.iter():
        if _local_name(element) in names and _text(element):
            return element
    return None


def _translator(title_stmt: Optional[ET.Element]) -> str:
    if title_stmt is None:
        return ""
    direct = _first_descendant(title_stmt, {"translator"})
    if direct is not None:
        return _text(direct)
    for response in title_stmt.iter():
        if _local_name(response) != "respStmt":
            continue
        response_text = _text(response).casefold()
        if "translat" in response_text:
            name = _first_descendant(response, {"name", "persName"})
            return _text(name)
    return ""


def _passages(root: ET.Element) -> list[tuple[str, str, str]]:
    body = _first_descendant(root, {"body"})
    if body is None:
        return []
    candidates = [
        element
        for element in body.iter()
        if _local_name(element) in {"p", "ab"} and _text(element)
    ]
    if not candidates:
        candidates = [
            element
            for element in body.iter()
            if _local_name(element) == "l" and _text(element)
        ]
    if not candidates:
        candidates = [body]
    result = []
    for index, element in enumerate(candidates, 1):
        native_id = (
            element.attrib.get(XML_ID)
            or element.attrib.get("n")
            or str(index)
        )
        language = element.attrib.get(XML_LANG, "")
        result.append((native_id, language, _text(element)))
    return result


class TeiAdapter(SourceAdapter):
    source_family = "tei"

    def parse_sample(
        self,
        payload: bytes,
        *,
        source: Mapping[str, Any],
        entities: Iterable[Entity],
        retrieved_at: datetime,
    ) -> list[dict[str, Any]]:
        del retrieved_at
        root = ET.fromstring(payload)
        defaults = source_defaults(source)
        title_stmt = _first_descendant(root, {"titleStmt"})
        title = _text(_first_descendant(title_stmt, {"title"}))
        author = _text(_first_descendant(title_stmt, {"author"}))
        translator = _translator(title_stmt)
        matcher = EntityMatcher(entities)
        base_locator = str(
            defaults.get("locator") or source.get("endpoint_url") or ""
        )
        records: list[dict[str, Any]] = []
        for native_id, language, excerpt in _passages(root):
            optional = {}
            if language and defaults.get("translation_method"):
                optional["original_language"] = language
                optional["translation_method"] = defaults["translation_method"]
            if defaults.get("translator_note"):
                optional["translator_note"] = defaults["translator_note"]
            for match in matcher.find(excerpt):
                records.append(
                    make_record(
                        match.entity,
                        match.alias,
                        record_type=str(
                            defaults.get("record_type", "text_excerpt")
                        ),
                        source_work=str(
                            defaults.get("source_work") or title or source["name"]
                        ),
                        source_author=str(
                            defaults.get("source_author")
                            or author
                            or "Unknown"
                        ),
                        translator=(
                            defaults.get("translator")
                            if "translator" in defaults
                            else translator or None
                        ),
                        corpus=str(defaults.get("corpus", "unknown")),
                        origin=str(
                            defaults.get("origin", "primary_source")
                        ),
                        locator=f"{base_locator}#{native_id}",
                        excerpt=excerpt,
                        optional=optional,
                    )
                )
        return records

