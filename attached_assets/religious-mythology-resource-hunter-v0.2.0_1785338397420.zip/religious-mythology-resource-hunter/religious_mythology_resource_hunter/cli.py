"""Command-line interface for catalog building and fixture-scale hunting."""

import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
import sys
from typing import Optional, Sequence

from religious_mythology_resource_hunter.catalog import (
    load_catalog,
    merge_entities,
    write_catalog,
)
from religious_mythology_resource_hunter.fetch import fetch_payload
from religious_mythology_resource_hunter.fulltext import (
    collect_fulltexts,
    verify_corpus,
)
from religious_mythology_resource_hunter.fulltext_sources import (
    load_fulltext_registry,
)
from religious_mythology_resource_hunter.fulltext_validation import (
    load_candidates,
    load_policy,
)
from religious_mythology_resource_hunter.pipeline import (
    merge_jsonl,
    parse_payload,
    prepare_records,
    write_jsonl,
    write_provenance,
)
from religious_mythology_resource_hunter.planning import plan_candidates
from religious_mythology_resource_hunter.validation import (
    load_registry,
    select_source,
    validate_jsonl,
)


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_REGISTRY = ROOT / "sources" / "registry.json"
DEFAULT_FULLTEXT_REGISTRY = ROOT / "sources" / "fulltext-registry.json"
DEFAULT_POLICY = ROOT / "config" / "collection-policy.json"


def _datetime(value: Optional[str]) -> datetime:
    if not value:
        return datetime.now(timezone.utc)
    normalized = value[:-1] + "+00:00" if value.endswith("Z") else value
    result = datetime.fromisoformat(normalized)
    if result.tzinfo is None:
        result = result.replace(tzinfo=timezone.utc)
    return result


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="rmrh",
        description=(
            "Download complete religious and mythological source texts with "
            "edition-level rights checks and publication locks."
        ),
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    plan = subparsers.add_parser(
        "plan",
        help="assess rights and prioritize complete text editions",
    )
    plan.add_argument("--candidates", type=Path, required=True)
    plan.add_argument("--policy", type=Path, default=DEFAULT_POLICY)
    plan.add_argument("--output", type=Path, required=True)
    plan.add_argument(
        "--assessed-at",
        help="ISO-8601 assessment time; defaults to current UTC time",
    )

    download = subparsers.add_parser(
        "download",
        help="download complete source texts into public/locked partitions",
    )
    download.add_argument("--candidates", type=Path, required=True)
    download.add_argument("--policy", type=Path, default=DEFAULT_POLICY)
    download.add_argument(
        "--registry", type=Path, default=DEFAULT_FULLTEXT_REGISTRY
    )
    download.add_argument("--output", type=Path, required=True)
    download.add_argument(
        "--selection",
        choices=["preferred", "all"],
        default="preferred",
        help="preferred follows language policy; all downloads every authorized edition",
    )
    download.add_argument(
        "--assessed-at",
        help="ISO-8601 rights/retrieval time; defaults to current UTC time",
    )
    download.add_argument(
        "--user-agent",
        default=None,
        help="operator-identifying user agent for remote downloads",
    )

    verify_corpus_parser = subparsers.add_parser(
        "verify-corpus",
        help="verify full-text checksums, partitions, and lock markers",
    )
    verify_corpus_parser.add_argument("--corpus", type=Path, required=True)

    catalog = subparsers.add_parser(
        "build-catalog",
        help="downstream extraction: build a deity matching catalog",
    )
    catalog.add_argument(
        "--input",
        type=Path,
        nargs="+",
        required=True,
        help="one or more SHADOWS JSON, catalog JSON, or resource JSONL files",
    )
    catalog.add_argument("--output", type=Path, required=True)

    validate = subparsers.add_parser(
        "validate", help="downstream extraction: validate excerpt JSONL"
    )
    validate.add_argument("--input", type=Path, required=True)

    hunt = subparsers.add_parser(
        "extract",
        aliases=["hunt"],
        help="downstream extraction: create deity-linked excerpts",
    )
    hunt.add_argument("--catalog", type=Path, required=True)
    hunt.add_argument("--registry", type=Path, default=DEFAULT_REGISTRY)
    hunt.add_argument("--source-id", required=True)
    input_group = hunt.add_mutually_exclusive_group(required=True)
    input_group.add_argument("--input", type=Path)
    input_group.add_argument("--url")
    hunt.add_argument("--output", type=Path, required=True)
    hunt.add_argument("--append", action="store_true")
    hunt.add_argument(
        "--keep-stable-ids",
        action="store_true",
        help="keep content-hash IDs instead of exact rec000000-style IDs",
    )
    hunt.add_argument(
        "--retrieved-at",
        help="ISO-8601 retrieval time; defaults to the current UTC time",
    )
    hunt.add_argument(
        "--user-agent",
        default=None,
        help="operator-identifying user agent for --url retrieval",
    )

    merge = subparsers.add_parser(
        "merge", help="downstream extraction: merge excerpt JSONL"
    )
    merge.add_argument("--input", type=Path, nargs="+", required=True)
    merge.add_argument("--output", type=Path, required=True)
    merge.add_argument("--keep-stable-ids", action="store_true")

    sources = subparsers.add_parser(
        "sources", help="list configured full-text source definitions"
    )
    sources.add_argument(
        "--registry", type=Path, default=DEFAULT_FULLTEXT_REGISTRY
    )
    return parser


def _plan_fulltexts(args: argparse.Namespace) -> int:
    candidates = load_candidates(args.candidates)
    policy = load_policy(args.policy)
    assessed_at = _datetime(args.assessed_at)
    plans = plan_candidates(
        candidates, policy, assessed_at=assessed_at
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", encoding="utf-8") as file:
        for plan in plans:
            file.write(
                json.dumps(plan, ensure_ascii=False, separators=(",", ":"))
            )
            file.write("\n")
    selected = sum(plan["selection"]["selected"] for plan in plans)
    locked = sum(
        plan["rights_assessment"]["locked"] for plan in plans
    )
    print(
        f"Planned {len(plans)} editions: {selected} selected, "
        f"{locked} locked; wrote {args.output}"
    )
    return 0


def _download_fulltexts(args: argparse.Namespace) -> int:
    candidates = load_candidates(args.candidates)
    policy = load_policy(args.policy)
    registry = load_fulltext_registry(args.registry)
    kwargs = {}
    if args.user_agent:
        kwargs["user_agent"] = args.user_agent
    records = collect_fulltexts(
        candidates,
        policy,
        registry,
        args.output,
        assessed_at=_datetime(args.assessed_at),
        selection_mode=args.selection,
        **kwargs,
    )
    statuses: dict[str, int] = {}
    for record in records:
        status = record["download_status"]
        statuses[status] = statuses.get(status, 0) + 1
    print(
        f"Processed {len(records)} editions into {args.output}: "
        + ", ".join(
            f"{key}={value}" for key, value in sorted(statuses.items())
        )
    )
    return 0 if not statuses.get("failed") else 1


def _verify_fulltext_corpus(args: argparse.Namespace) -> int:
    counts = verify_corpus(args.corpus)
    print(
        "Verified corpus: "
        + ", ".join(f"{key}={value}" for key, value in counts.items())
    )
    return 0


def _build_catalog(args: argparse.Namespace) -> int:
    entities = merge_entities(
        entity
        for input_path in args.input
        for entity in load_catalog(input_path)
    )
    write_catalog(args.output, entities)
    print(f"Wrote {len(entities)} entities to {args.output}")
    return 0


def _validate(args: argparse.Namespace) -> int:
    count = validate_jsonl(args.input)
    print(f"Validated {count} records in {args.input}")
    return 0


def _hunt(args: argparse.Namespace) -> int:
    registry = load_registry(args.registry)
    source = select_source(registry, args.source_id)
    entities = load_catalog(args.catalog)
    retrieved_at = _datetime(args.retrieved_at)
    if args.input:
        payload = args.input.read_bytes()
        input_reference = str(args.input.resolve())
        media_type = None
    else:
        fetch_kwargs = {}
        if args.user_agent:
            fetch_kwargs["user_agent"] = args.user_agent
        payload, media_type = fetch_payload(args.url, source, **fetch_kwargs)
        input_reference = args.url
    records = parse_payload(
        payload,
        source=source,
        entities=entities,
        retrieved_at=retrieved_at,
    )
    if args.append and args.output.exists():
        from religious_mythology_resource_hunter.validation import iter_jsonl

        records = list(iter_jsonl(args.output)) + records
    records = prepare_records(
        records, sequential_ids=not args.keep_stable_ids
    )
    write_jsonl(args.output, records)
    provenance_path = args.output.with_suffix(
        args.output.suffix + ".provenance.json"
    )
    write_provenance(
        provenance_path,
        source=source,
        retrieved_at=retrieved_at,
        payload=payload,
        record_count=len(records),
        input_reference=input_reference,
        media_type=media_type,
    )
    print(
        f"Wrote {len(records)} records to {args.output} "
        f"and provenance to {provenance_path}"
    )
    return 0


def _merge(args: argparse.Namespace) -> int:
    records = merge_jsonl(
        args.input,
        args.output,
        sequential_ids=not args.keep_stable_ids,
    )
    print(f"Wrote {len(records)} unique records to {args.output}")
    return 0


def _sources(args: argparse.Namespace) -> int:
    registry = load_fulltext_registry(args.registry)
    for source in registry["sources"]:
        print(
            "\t".join(
                [
                    source["source_id"],
                    source["name"],
                    (
                        "local"
                        if source["local_only"]
                        else "remote"
                    ),
                    (
                        "enabled"
                        if source["automated_download_allowed"]
                        else "disabled"
                    ),
                ]
            )
        )
    return 0


def main(argv: Optional[Sequence[str]] = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    handlers = {
        "plan": _plan_fulltexts,
        "download": _download_fulltexts,
        "verify-corpus": _verify_fulltext_corpus,
        "build-catalog": _build_catalog,
        "validate": _validate,
        "extract": _hunt,
        "hunt": _hunt,
        "merge": _merge,
        "sources": _sources,
    }
    try:
        return handlers[args.command](args)
    except (KeyError, OSError, ValueError) as error:
        print(f"error: {error}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
