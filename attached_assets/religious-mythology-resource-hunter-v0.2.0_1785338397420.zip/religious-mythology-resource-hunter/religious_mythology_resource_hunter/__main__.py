from religious_mythology_resource_hunter.cli import main


if __name__ == "__main__":
    raise SystemExit(main())

