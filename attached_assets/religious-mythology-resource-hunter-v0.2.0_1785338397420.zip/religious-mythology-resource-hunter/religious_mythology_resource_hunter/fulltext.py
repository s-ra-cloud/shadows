"""Download complete source texts into public/locked corpus partitions."""

from datetime import datetime
from hashlib import sha256
import json
import mimetypes
import os
from pathlib import Path
import tempfile
import time
from typing import Any, Iterable, Mapping, Optional
from urllib.parse import urlparse
from urllib.request import Request, urlopen
from urllib.robotparser import RobotFileParser

from religious_mythology_resource_hunter.fulltext_sources import (
    select_fulltext_source,
    validate_candidate_access,
    validate_remote_url,
)
from religious_mythology_resource_hunter.normalization import slug
from religious_mythology_resource_hunter.planning import plan_candidates
from religious_mythology_resource_hunter.rights import (
    assess_rights,
    extract_embedded_notice,
)


DEFAULT_USER_AGENT = (
    "ReligiousMythologyResourceHunter/0.2 "
    "(rights-aware research corpus collector)"
)

EXTENSIONS = {
    "txt": ".txt",
    "tei_xml": ".xml",
    "xml": ".xml",
    "html": ".html",
    "epub": ".epub",
    "pdf": ".pdf",
    "json": ".json",
}


class _Throttle:
    def __init__(self) -> None:
        self._last_request: dict[str, float] = {}

    def wait(self, source: Mapping[str, Any]) -> None:
        source_id = str(source["source_id"])
        interval = 1.0 / float(source["requests_per_second"])
        previous = self._last_request.get(source_id)
        if previous is not None:
            remaining = interval - (time.monotonic() - previous)
            if remaining > 0:
                time.sleep(min(remaining, 60.0))
        self._last_request[source_id] = time.monotonic()


def _download_id(candidate: Mapping[str, Any]) -> str:
    identity = "|".join(
        [
            str(candidate["work_id"]),
            str(candidate["edition_id"]),
            str(candidate.get("text_url") or candidate.get("local_path")),
        ]
    ).encode("utf-8")
    return "download:" + sha256(identity).hexdigest()[:16]


def _checksum(payload: bytes) -> str:
    return "sha256:" + sha256(payload).hexdigest()


def _robots_allowed(
    url: str, source: Mapping[str, Any], user_agent: str
) -> bool:
    if source["robots_mode"] == "not_applicable":
        return True
    parsed = urlparse(url)
    robots_url = f"{parsed.scheme}://{parsed.netloc}/robots.txt"
    parser = RobotFileParser()
    parser.set_url(robots_url)
    parser.read()
    return parser.can_fetch(user_agent, url)


def _read_candidate_payload(
    candidate: Mapping[str, Any],
    source: Mapping[str, Any],
    *,
    user_agent: str,
    maximum_bytes: int,
    throttle: _Throttle,
) -> tuple[bytes, Optional[str]]:
    validate_candidate_access(candidate, source)
    if candidate.get("local_path"):
        path = Path(str(candidate["local_path"]))
        if not path.is_file():
            raise FileNotFoundError(f"local full text does not exist: {path}")
        if path.stat().st_size > maximum_bytes:
            raise ValueError("local full text exceeds maximum_file_bytes")
        return path.read_bytes(), mimetypes.guess_type(path.name)[0]

    url = str(candidate["text_url"])
    if not _robots_allowed(url, source, user_agent):
        raise PermissionError(f"robots policy disallows download: {url}")
    throttle.wait(source)
    request = Request(
        url,
        headers={
            "Accept": (
                "text/plain, application/xml, text/xml, text/html, "
                "application/epub+zip, application/pdf, application/json"
            ),
            "User-Agent": user_agent,
        },
    )
    with urlopen(request, timeout=60) as response:
        validate_remote_url(response.geturl(), source)
        payload = response.read(maximum_bytes + 1)
        content_type = response.headers.get_content_type()
    if len(payload) > maximum_bytes:
        raise ValueError("remote full text exceeds maximum_file_bytes")
    return payload, content_type


def _edition_paths(
    corpus_root: Path,
    candidate: Mapping[str, Any],
    *,
    locked: bool,
) -> tuple[Path, Path, Optional[Path]]:
    work_component = slug(str(candidate["work_id"]).split(":", 1)[-1])
    edition_component = slug(
        str(candidate["edition_id"]).split(":", 1)[-1]
    )
    extension = EXTENSIONS[str(candidate["format"])]
    partition = "locked" if locked else "public"
    text_path = (
        corpus_root
        / partition
        / work_component
        / f"{edition_component}{extension}"
    )
    rights_path = (
        corpus_root
        / "rights"
        / work_component
        / f"{edition_component}.rights.json"
    )
    lock_path = (
        text_path.with_suffix(text_path.suffix + ".LOCK.json")
        if locked
        else None
    )
    return text_path, rights_path, lock_path


def _atomic_write(path: Path, payload: bytes, mode: int) -> str:
    path.parent.mkdir(parents=True, exist_ok=True)
    checksum = _checksum(payload)
    if path.exists():
        existing = path.read_bytes()
        if _checksum(existing) != checksum:
            raise FileExistsError(
                f"refusing to overwrite different existing file: {path}"
            )
        os.chmod(path, mode)
        return "already_present"
    with tempfile.NamedTemporaryFile(
        dir=path.parent, prefix=".partial-", delete=False
    ) as temporary:
        temporary.write(payload)
        temporary_path = Path(temporary.name)
    os.chmod(temporary_path, mode)
    os.replace(temporary_path, path)
    return "downloaded"


def _write_json(path: Path, value: Mapping[str, Any], mode: int) -> None:
    payload = (
        json.dumps(value, ensure_ascii=False, indent=2) + "\n"
    ).encode("utf-8")
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and path.read_bytes() == payload:
        os.chmod(path, mode)
        return
    with tempfile.NamedTemporaryFile(
        dir=path.parent, prefix=".metadata-", delete=False
    ) as temporary:
        temporary.write(payload)
        temporary_path = Path(temporary.name)
    os.chmod(temporary_path, mode)
    os.replace(temporary_path, path)


def _relative(path: Optional[Path], root: Path) -> Optional[str]:
    if path is None:
        return None
    return str(path.relative_to(root))


def _base_record(
    plan: Mapping[str, Any], selection: Mapping[str, Any]
) -> dict[str, Any]:
    candidate = plan["candidate"]
    return {
        "schema_version": "1.0.0",
        "download_id": _download_id(candidate),
        "work_id": candidate["work_id"],
        "edition_id": candidate["edition_id"],
        "title": candidate["title"],
        "author": candidate.get("author"),
        "translator": candidate.get("translator"),
        "language": candidate["language"],
        "language_role": candidate["language_role"],
        "original_language": candidate.get("original_language"),
        "source_id": candidate["source_id"],
        "source_reference": str(
            candidate.get("text_url") or candidate.get("local_path")
        ),
        "format": candidate["format"],
        "selection": dict(selection),
        "rights": plan["rights_assessment"],
        "download_status": "not_selected",
        "file": None,
        "error": None,
        "retrieved_at": None,
    }


def _write_corpus_readme(root: Path) -> None:
    path = root / "README.txt"
    content = (
        "FULL-TEXT CORPUS\n\n"
        "public/ contains editions whose explicit rights evidence permits "
        "publication under the configured policy.\n"
        "locked/ contains research copies that MUST NOT be republished. "
        "Every locked file has a .LOCK.json marker and restrictive local "
        "permissions.\n"
        "rights/ contains the per-edition decision and evidence. "
        "corpus.jsonl is the machine-readable index.\n\n"
        "A lock is a safety control, not a legal determination or DRM.\n"
    ).encode("utf-8")
    if path.exists() and path.read_bytes() == content:
        return
    if path.exists():
        raise FileExistsError(f"refusing to overwrite corpus README: {path}")
    _atomic_write(path, content, 0o644)


def collect_fulltexts(
    candidates: Iterable[dict[str, Any]],
    policy: Mapping[str, Any],
    registry: Mapping[str, Any],
    corpus_root: Path,
    *,
    assessed_at: datetime,
    selection_mode: str = "preferred",
    user_agent: str = DEFAULT_USER_AGENT,
) -> list[dict[str, Any]]:
    if selection_mode not in {"preferred", "all"}:
        raise ValueError("selection_mode must be preferred or all")
    plans = plan_candidates(candidates, policy, assessed_at=assessed_at)
    corpus_root.mkdir(parents=True, exist_ok=True)
    _write_corpus_readme(corpus_root)
    throttle = _Throttle()
    records: list[dict[str, Any]] = []
    for plan in plans:
        candidate = plan["candidate"]
        selection = dict(plan["selection"])
        if selection_mode == "all" and candidate["access"]["download_allowed"]:
            selection = {
                "selected": True,
                "reason": "all_authorized_editions",
                "rank": 50,
            }
        record = _base_record(plan, selection)
        if not selection["selected"]:
            records.append(record)
            continue
        if (
            not candidate["access"]["download_allowed"]
            or candidate["access"].get("requires_auth", False)
        ):
            record["download_status"] = "metadata_only"
            records.append(record)
            continue
        try:
            source = select_fulltext_source(
                registry, str(candidate["source_id"])
            )
            payload, content_type = _read_candidate_payload(
                candidate,
                source,
                user_agent=user_agent,
                maximum_bytes=int(policy["maximum_file_bytes"]),
                throttle=throttle,
            )
            embedded_notice = extract_embedded_notice(
                payload, str(candidate["format"])
            )
            final_rights = assess_rights(
                candidate,
                policy,
                embedded_notice=embedded_notice,
                assessed_at=assessed_at,
            )
            record["rights"] = final_rights
            text_path, rights_path, lock_path = _edition_paths(
                corpus_root,
                candidate,
                locked=final_rights["locked"],
            )
            status = _atomic_write(
                text_path,
                payload,
                0o600 if final_rights["locked"] else 0o644,
            )
            rights_document = {
                "schema_version": "1.0.0",
                "work_id": candidate["work_id"],
                "edition_id": candidate["edition_id"],
                "source_id": candidate["source_id"],
                "source_reference": record["source_reference"],
                "rights": final_rights,
                "candidate_rights_evidence": candidate["rights"],
                "file_sha256": _checksum(payload),
            }
            _write_json(
                rights_path,
                rights_document,
                0o600 if final_rights["locked"] else 0o644,
            )
            if lock_path:
                lock_document = {
                    "locked": True,
                    "do_not_publish": True,
                    "work_id": candidate["work_id"],
                    "edition_id": candidate["edition_id"],
                    "rights_status": final_rights["status"],
                    "reasons": final_rights["reasons"],
                    "rights_record": _relative(rights_path, corpus_root),
                }
                _write_json(lock_path, lock_document, 0o600)
            record["download_status"] = status
            record["retrieved_at"] = assessed_at.isoformat()
            record["file"] = {
                "relative_path": _relative(text_path, corpus_root),
                "bytes": len(payload),
                "sha256": _checksum(payload),
                "content_type": content_type,
                "locked": final_rights["locked"],
                "lock_path": _relative(lock_path, corpus_root),
                "rights_path": _relative(rights_path, corpus_root),
            }
        except PermissionError as error:
            record["download_status"] = "metadata_only"
            record["error"] = str(error)
        except (KeyError, OSError, ValueError) as error:
            record["download_status"] = "failed"
            record["error"] = str(error)
        records.append(record)
    write_corpus_manifest(corpus_root / "corpus.jsonl", records)
    return records


def write_corpus_manifest(
    path: Path, records: Iterable[Mapping[str, Any]]
) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    lines = [
        json.dumps(record, ensure_ascii=False, separators=(",", ":"))
        for record in records
    ]
    payload = (("\n".join(lines) + "\n") if lines else "").encode("utf-8")
    with tempfile.NamedTemporaryFile(
        dir=path.parent, prefix=".manifest-", delete=False
    ) as temporary:
        temporary.write(payload)
        temporary_path = Path(temporary.name)
    os.chmod(temporary_path, 0o644)
    os.replace(temporary_path, path)


def iter_corpus_manifest(path: Path) -> Iterable[dict[str, Any]]:
    with path.open(encoding="utf-8") as file:
        for line_number, line in enumerate(file, 1):
            if not line.strip():
                continue
            value = json.loads(line)
            if not isinstance(value, dict):
                raise ValueError(
                    f"{path}:{line_number}: corpus record is not an object"
                )
            yield value


def verify_corpus(corpus_root: Path) -> dict[str, int]:
    manifest_path = corpus_root / "corpus.jsonl"
    counts = {
        "records": 0,
        "downloaded": 0,
        "public": 0,
        "locked": 0,
        "metadata_only": 0,
        "not_selected": 0,
        "failed": 0,
    }
    root = corpus_root.resolve()
    for record in iter_corpus_manifest(manifest_path):
        counts["records"] += 1
        status = record["download_status"]
        if status in {"downloaded", "already_present"}:
            counts["downloaded"] += 1
            file_info = record.get("file")
            if not isinstance(file_info, dict):
                raise ValueError("downloaded corpus record has no file")
            path = (corpus_root / file_info["relative_path"]).resolve()
            try:
                path.relative_to(root)
            except ValueError as error:
                raise ValueError("corpus file escapes corpus root") from error
            if not path.is_file():
                raise FileNotFoundError(f"missing corpus file: {path}")
            payload = path.read_bytes()
            if len(payload) != file_info["bytes"]:
                raise ValueError(f"byte count mismatch: {path}")
            if _checksum(payload) != file_info["sha256"]:
                raise ValueError(f"checksum mismatch: {path}")
            rights_relative = file_info.get("rights_path")
            if not rights_relative:
                raise ValueError(f"corpus file has no rights record: {path}")
            rights_path = (corpus_root / rights_relative).resolve()
            try:
                rights_path.relative_to(root)
            except ValueError as error:
                raise ValueError(
                    "rights record escapes corpus root"
                ) from error
            if not rights_path.is_file():
                raise FileNotFoundError(
                    f"missing rights record: {rights_path}"
                )
            with rights_path.open(encoding="utf-8") as file:
                rights_document = json.load(file)
            if rights_document.get("edition_id") != record["edition_id"]:
                raise ValueError(
                    f"rights record edition mismatch: {rights_path}"
                )
            if rights_document.get("file_sha256") != file_info["sha256"]:
                raise ValueError(
                    f"rights record checksum mismatch: {rights_path}"
                )
            if file_info["locked"]:
                counts["locked"] += 1
                if not file_info.get("lock_path"):
                    raise ValueError(f"locked file has no lock marker: {path}")
                lock_path = (
                    corpus_root / file_info["lock_path"]
                ).resolve()
                try:
                    lock_path.relative_to(root)
                except ValueError as error:
                    raise ValueError(
                        "lock marker escapes corpus root"
                    ) from error
                if not lock_path.is_file():
                    raise FileNotFoundError(
                        f"missing lock marker: {lock_path}"
                    )
                with lock_path.open(encoding="utf-8") as file:
                    lock_document = json.load(file)
                if (
                    not lock_document.get("do_not_publish")
                    or lock_document.get("edition_id")
                    != record["edition_id"]
                ):
                    raise ValueError(
                        f"invalid lock marker: {lock_path}"
                    )
                if (
                    path.stat().st_mode & 0o077
                    or lock_path.stat().st_mode & 0o077
                    or rights_path.stat().st_mode & 0o077
                ):
                    raise PermissionError(
                        f"locked material permissions are too broad: {path}"
                    )
                if record["rights"]["publication_allowed"]:
                    raise ValueError(
                        f"locked file marked publishable: {path}"
                    )
            else:
                counts["public"] += 1
                if not record["rights"]["publication_allowed"]:
                    raise ValueError(
                        f"public file is not cleared for publication: {path}"
                    )
        elif status in counts:
            counts[status] += 1
        else:
            raise ValueError(f"unsupported download_status: {status}")
    return counts
