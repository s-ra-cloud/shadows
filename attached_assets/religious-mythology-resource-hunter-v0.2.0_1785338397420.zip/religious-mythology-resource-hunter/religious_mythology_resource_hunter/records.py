"""Construction of records compatible with deity_excerpts.jsonl."""

from hashlib import sha256
import json
from typing import Any, Mapping, Optional

from religious_mythology_resource_hunter.catalog import Entity
from religious_mythology_resource_hunter.normalization import (
    normalize_space,
    word_count,
)


COMMON_FIELDS = (
    "deity",
    "tradition",
    "gender",
    "matched_alias",
    "record_type",
    "source_work",
    "source_author",
    "translator",
    "corpus",
    "origin",
    "locator",
    "excerpt",
    "n_words",
    "id",
)

OPTIONAL_FIELDS = (
    "url",
    "artwork_title",
    "artwork_date",
    "artwork_medium",
    "artwork_classification",
    "match_confidence",
    "excerpt_original",
    "original_language",
    "translation_method",
    "translator_note",
)


def stable_record_id(record: Mapping[str, Any]) -> str:
    identity = {
        key: record.get(key)
        for key in (
            "deity",
            "tradition",
            "record_type",
            "locator",
            "excerpt",
        )
    }
    payload = json.dumps(
        identity,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return "rec" + sha256(payload).hexdigest()[:16]


def make_record(
    entity: Entity,
    matched_alias: str,
    *,
    record_type: str,
    source_work: str,
    source_author: str,
    translator: Optional[str],
    corpus: str,
    origin: str,
    locator: str,
    excerpt: str,
    optional: Optional[Mapping[str, Any]] = None,
) -> dict[str, Any]:
    clean_excerpt = normalize_space(excerpt)
    record: dict[str, Any] = {
        "deity": entity.name,
        "tradition": entity.tradition,
        "gender": entity.gender,
        "matched_alias": normalize_space(matched_alias),
        "record_type": record_type,
        "source_work": normalize_space(source_work),
        "source_author": normalize_space(source_author),
        "translator": normalize_space(translator) if translator else None,
        "corpus": normalize_space(corpus),
        "origin": normalize_space(origin),
        "locator": normalize_space(locator),
        "excerpt": clean_excerpt,
        "n_words": word_count(clean_excerpt),
    }
    for key, value in (optional or {}).items():
        if key not in OPTIONAL_FIELDS or value is None:
            continue
        record[key] = normalize_space(value)
    record["id"] = stable_record_id(record)
    return record

