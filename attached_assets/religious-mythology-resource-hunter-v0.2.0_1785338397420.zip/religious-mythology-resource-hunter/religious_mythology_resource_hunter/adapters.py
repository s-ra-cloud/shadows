"""Reusable, deterministic source-adapter contract."""

from abc import ABC, abstractmethod
from datetime import datetime
from typing import Any, Iterable, Mapping

from religious_mythology_resource_hunter.catalog import Entity
from religious_mythology_resource_hunter.validation import validate_record


class SourceAdapter(ABC):
    """Parse one immutable payload from a reusable source family."""

    source_family: str

    @abstractmethod
    def parse_sample(
        self,
        payload: bytes,
        *,
        source: Mapping[str, Any],
        entities: Iterable[Entity],
        retrieved_at: datetime,
    ) -> list[dict[str, Any]]:
        """Return canonical resource records without persistent writes."""


def source_defaults(source: Mapping[str, Any]) -> Mapping[str, Any]:
    defaults = source.get("defaults", {})
    if not isinstance(defaults, dict):
        raise ValueError("source defaults must be an object")
    return defaults


def run_sample(
    adapter: SourceAdapter,
    source: Mapping[str, Any],
    payload: bytes,
    entities: Iterable[Entity],
    retrieved_at: datetime,
) -> list[dict[str, Any]]:
    """Parse and validate every record at the adapter boundary."""
    if source["source_family"] != adapter.source_family:
        raise ValueError(
            "source definition source_family does not match adapter source_family"
        )
    records = adapter.parse_sample(
        payload,
        source=source,
        entities=entities,
        retrieved_at=retrieved_at,
    )
    for record in records:
        validate_record(record)
    return records

