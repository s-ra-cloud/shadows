"""Adapter orchestration, deduplication, JSONL output, and provenance."""

from datetime import datetime
from hashlib import sha256
import json
from pathlib import Path
from typing import Any, Iterable, Mapping, Optional

from religious_mythology_resource_hunter.adapters import (
    SourceAdapter,
    run_sample,
)
from religious_mythology_resource_hunter.catalog import Entity
from religious_mythology_resource_hunter.iiif import IiifAdapter
from religious_mythology_resource_hunter.legacy_jsonl import LegacyJsonlAdapter
from religious_mythology_resource_hunter.mediawiki import MediaWikiAdapter
from religious_mythology_resource_hunter.oai_dc import OaiDcAdapter
from religious_mythology_resource_hunter.plain_text import PlainTextAdapter
from religious_mythology_resource_hunter.tei import TeiAdapter
from religious_mythology_resource_hunter.validation import (
    iter_jsonl,
    validate_records,
)


ADAPTERS: dict[str, type[SourceAdapter]] = {
    "iiif": IiifAdapter,
    "legacy_jsonl": LegacyJsonlAdapter,
    "mediawiki": MediaWikiAdapter,
    "oai_dc": OaiDcAdapter,
    "plain_text": PlainTextAdapter,
    "tei": TeiAdapter,
}


def adapter_for(source_family: str) -> SourceAdapter:
    try:
        adapter_class = ADAPTERS[source_family]
    except KeyError as error:
        raise ValueError(
            f"no adapter registered for source family {source_family!r}"
        ) from error
    return adapter_class()


def _fingerprint(record: Mapping[str, Any]) -> str:
    value = {key: record[key] for key in record if key != "id"}
    return json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    )


def deduplicate_records(
    records: Iterable[dict[str, Any]],
) -> list[dict[str, Any]]:
    result = []
    seen = set()
    for record in records:
        fingerprint = _fingerprint(record)
        if fingerprint in seen:
            continue
        seen.add(fingerprint)
        result.append(dict(record))
    return result


def assign_sequential_ids(
    records: Iterable[dict[str, Any]],
) -> list[dict[str, Any]]:
    result = []
    for index, record in enumerate(records):
        copy = dict(record)
        copy["id"] = f"rec{index:06d}"
        result.append(copy)
    return result


def prepare_records(
    records: Iterable[dict[str, Any]], *, sequential_ids: bool = True
) -> list[dict[str, Any]]:
    result = deduplicate_records(records)
    if sequential_ids:
        result = assign_sequential_ids(result)
    validate_records(result)
    return result


def parse_payload(
    payload: bytes,
    *,
    source: Mapping[str, Any],
    entities: Iterable[Entity],
    retrieved_at: datetime,
) -> list[dict[str, Any]]:
    adapter = adapter_for(str(source["source_family"]))
    return run_sample(adapter, source, payload, entities, retrieved_at)


def write_jsonl(path: Path, records: Iterable[Mapping[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as file:
        for record in records:
            file.write(
                json.dumps(record, ensure_ascii=False, separators=(",", ":"))
            )
            file.write("\n")


def merge_jsonl(
    inputs: Iterable[Path],
    output: Path,
    *,
    sequential_ids: bool = True,
) -> list[dict[str, Any]]:
    records = []
    for path in inputs:
        records.extend(iter_jsonl(path))
    result = prepare_records(records, sequential_ids=sequential_ids)
    write_jsonl(output, result)
    return result


def payload_checksum(payload: bytes) -> str:
    return "sha256:" + sha256(payload).hexdigest()


def write_provenance(
    path: Path,
    *,
    source: Mapping[str, Any],
    retrieved_at: datetime,
    payload: bytes,
    record_count: int,
    input_reference: str,
    media_type: Optional[str] = None,
) -> None:
    access = source.get("access", {})
    document = {
        "schema_version": "1.0.0",
        "source_id": source["source_id"],
        "source_name": source["name"],
        "source_family": source["source_family"],
        "input_reference": input_reference,
        "retrieved_at": retrieved_at.isoformat(),
        "payload_checksum": payload_checksum(payload),
        "payload_bytes": len(payload),
        "media_type": media_type,
        "record_count": record_count,
        "rights": {
            "license": access.get("license"),
            "terms_url": access.get("terms_url"),
            "reuse_notes": access.get("reuse_notes"),
        },
    }
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as file:
        json.dump(document, file, ensure_ascii=False, indent=2)
        file.write("\n")

