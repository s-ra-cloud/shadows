"""Validation and loading for full-text candidates and collection policy."""

import json
from pathlib import Path
import re
from typing import Any, Iterable, Mapping
from urllib.parse import urlparse


class FullTextValidationError(ValueError):
    pass


LANGUAGE_ROLES = {"original", "translation", "parallel", "unknown"}
RIGHTS_CLAIMS = {
    "public_domain",
    "open_license",
    "copyrighted",
    "unknown",
}
FORMATS = {
    "txt",
    "tei_xml",
    "xml",
    "html",
    "epub",
    "pdf",
    "json",
}


def _http_url(value: object) -> bool:
    if not isinstance(value, str):
        return False
    parsed = urlparse(value)
    return parsed.scheme in {"http", "https"} and bool(parsed.netloc)


def validate_candidate(candidate: Mapping[str, Any]) -> None:
    required = {
        "work_id",
        "edition_id",
        "title",
        "author",
        "source_id",
        "language",
        "language_role",
        "format",
        "rights",
        "access",
    }
    missing = required - set(candidate)
    if missing:
        raise FullTextValidationError(
            f"candidate is missing fields: {sorted(missing)}"
        )
    for field in ("work_id", "edition_id", "source_id"):
        value = candidate[field]
        if not isinstance(value, str) or not re.fullmatch(
            r"[a-z][a-z0-9_-]*:.+", value
        ):
            raise FullTextValidationError(f"invalid {field}: {value!r}")
    for field in ("title", "language"):
        if not isinstance(candidate[field], str) or not candidate[field].strip():
            raise FullTextValidationError(f"{field} must be a non-empty string")
    if candidate["author"] is not None and not isinstance(
        candidate["author"], str
    ):
        raise FullTextValidationError("author must be a string or null")
    if candidate.get("translator") is not None and not isinstance(
        candidate["translator"], str
    ):
        raise FullTextValidationError("translator must be a string or null")
    if candidate["language_role"] not in LANGUAGE_ROLES:
        raise FullTextValidationError("unsupported language_role")
    if candidate["format"] not in FORMATS:
        raise FullTextValidationError("unsupported full-text format")
    if not candidate.get("text_url") and not candidate.get("local_path"):
        raise FullTextValidationError(
            "candidate needs text_url or local_path"
        )
    if candidate.get("text_url") and not _http_url(candidate["text_url"]):
        raise FullTextValidationError("text_url must be HTTP(S)")
    if candidate.get("metadata_url") and not _http_url(
        candidate["metadata_url"]
    ):
        raise FullTextValidationError("metadata_url must be HTTP(S)")
    for year_field in (
        "publication_year",
        "copyright_author_death_year",
    ):
        year = candidate.get(year_field)
        if year is not None and (
            not isinstance(year, int)
            or isinstance(year, bool)
            or not 1 <= year <= 9999
        ):
            raise FullTextValidationError(f"invalid {year_field}")

    rights = candidate["rights"]
    if not isinstance(rights, dict):
        raise FullTextValidationError("rights must be an object")
    if rights.get("status_claim", "unknown") not in RIGHTS_CLAIMS:
        raise FullTextValidationError("unsupported rights status_claim")
    territories = rights.get("territories", [])
    if not isinstance(territories, list) or any(
        not isinstance(item, str) or not item.strip() for item in territories
    ):
        raise FullTextValidationError("rights territories must be strings")
    for url_field in ("license_url", "rights_url"):
        if rights.get(url_field) and not _http_url(rights[url_field]):
            raise FullTextValidationError(f"invalid rights {url_field}")

    access = candidate["access"]
    if not isinstance(access, dict):
        raise FullTextValidationError("access must be an object")
    if not isinstance(access.get("download_allowed"), bool):
        raise FullTextValidationError(
            "access.download_allowed must be boolean"
        )
    if not isinstance(access.get("requires_auth", False), bool):
        raise FullTextValidationError("access.requires_auth must be boolean")


def validate_policy(policy: Mapping[str, Any]) -> None:
    if policy.get("schema_version") != "1.0.0":
        raise FullTextValidationError(
            "policy schema_version must be 1.0.0"
        )
    if not isinstance(policy.get("target_jurisdiction"), str):
        raise FullTextValidationError(
            "policy target_jurisdiction is required"
        )
    current_year = policy.get("current_year")
    if not isinstance(current_year, int) or not 1900 <= current_year <= 9999:
        raise FullTextValidationError("policy current_year is invalid")
    for field in ("ai_translatable_languages", "preferred_formats"):
        values = policy.get(field)
        if not isinstance(values, list) or not values:
            raise FullTextValidationError(f"policy {field} must be an array")
        if any(not isinstance(item, str) or not item for item in values):
            raise FullTextValidationError(f"policy {field} has invalid values")
    if not isinstance(policy.get("unlock_likely_public_domain"), bool):
        raise FullTextValidationError(
            "policy unlock_likely_public_domain must be boolean"
        )
    maximum = policy.get("maximum_file_bytes")
    if (
        not isinstance(maximum, int)
        or isinstance(maximum, bool)
        or maximum <= 0
    ):
        raise FullTextValidationError(
            "policy maximum_file_bytes must be a positive integer"
        )


def load_policy(path: Path) -> dict[str, Any]:
    with path.open(encoding="utf-8") as file:
        policy = json.load(file)
    if not isinstance(policy, dict):
        raise FullTextValidationError("policy must be a JSON object")
    validate_policy(policy)
    return policy


def iter_candidates(path: Path) -> Iterable[dict[str, Any]]:
    with path.open(encoding="utf-8") as file:
        for line_number, line in enumerate(file, 1):
            if not line.strip():
                continue
            try:
                candidate = json.loads(line)
            except json.JSONDecodeError as error:
                raise FullTextValidationError(
                    f"{path}:{line_number}: invalid JSON: {error.msg}"
                ) from error
            if not isinstance(candidate, dict):
                raise FullTextValidationError(
                    f"{path}:{line_number}: candidate must be an object"
                )
            validate_candidate(candidate)
            if candidate.get("local_path"):
                local_path = Path(candidate["local_path"])
                if not local_path.is_absolute():
                    candidate = dict(candidate)
                    candidate["local_path"] = str(
                        (path.parent / local_path).resolve()
                    )
            yield candidate


def load_candidates(path: Path) -> list[dict[str, Any]]:
    candidates = list(iter_candidates(path))
    edition_ids = [candidate["edition_id"] for candidate in candidates]
    if len(edition_ids) != len(set(edition_ids)):
        raise FullTextValidationError(
            "candidate file contains duplicate edition_id"
        )
    return candidates
