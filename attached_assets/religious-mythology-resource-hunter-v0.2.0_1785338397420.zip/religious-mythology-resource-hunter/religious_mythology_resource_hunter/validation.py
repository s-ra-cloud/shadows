"""Validation for the canonical JSONL record and source registry."""

import json
from pathlib import Path
import re
from typing import Any, Iterable, Mapping
from urllib.parse import urlparse

from religious_mythology_resource_hunter.normalization import word_count
from religious_mythology_resource_hunter.records import (
    COMMON_FIELDS,
    OPTIONAL_FIELDS,
)


class RecordValidationError(ValueError):
    pass


RECORD_TYPES = {"text_excerpt", "art_description", "museum_object"}
SOURCE_FAMILIES = {
    "iiif",
    "legacy_jsonl",
    "mediawiki",
    "oai_dc",
    "plain_text",
    "tei",
}


def _is_http_url(value: object) -> bool:
    if not isinstance(value, str):
        return False
    parsed = urlparse(value)
    return parsed.scheme in {"http", "https"} and bool(parsed.netloc)


def validate_record(record: Mapping[str, Any]) -> None:
    missing = set(COMMON_FIELDS) - set(record)
    if missing:
        raise RecordValidationError(
            f"record is missing required fields: {sorted(missing)}"
        )
    unexpected = set(record) - set(COMMON_FIELDS) - set(OPTIONAL_FIELDS)
    if unexpected:
        raise RecordValidationError(
            f"record has unexpected fields: {sorted(unexpected)}"
        )
    for key in COMMON_FIELDS:
        if key == "translator":
            if record[key] is not None and not isinstance(record[key], str):
                raise RecordValidationError("translator must be a string or null")
        elif key == "n_words":
            if (
                not isinstance(record[key], int)
                or isinstance(record[key], bool)
                or record[key] < 0
            ):
                raise RecordValidationError("n_words must be a non-negative integer")
        elif not isinstance(record[key], str):
            raise RecordValidationError(f"{key} must be a string")
    for key in set(record).intersection(OPTIONAL_FIELDS):
        if not isinstance(record[key], str):
            raise RecordValidationError(f"{key} must be a string")
    if record["record_type"] not in RECORD_TYPES:
        raise RecordValidationError(
            f"unsupported record_type: {record['record_type']!r}"
        )
    if not re.fullmatch(r"rec[0-9a-f]{6,32}", record["id"]):
        raise RecordValidationError(
            "id must start with rec and contain 6-32 lowercase hex characters"
        )
    actual_words = word_count(record["excerpt"])
    if record["n_words"] != actual_words:
        raise RecordValidationError(
            f"n_words is {record['n_words']}, expected {actual_words}"
        )
    if "url" in record and record["url"] and not _is_http_url(record["url"]):
        raise RecordValidationError("url must be an absolute HTTP(S) URL")
    if record["record_type"] == "museum_object":
        needed = {
            "url",
            "artwork_title",
            "artwork_date",
            "artwork_medium",
            "artwork_classification",
            "match_confidence",
        }
        absent = needed - set(record)
        if absent:
            raise RecordValidationError(
                f"museum_object is missing fields: {sorted(absent)}"
            )


def validate_records(records: Iterable[Mapping[str, Any]]) -> int:
    seen: set[str] = set()
    count = 0
    for index, record in enumerate(records, 1):
        try:
            validate_record(record)
        except RecordValidationError as error:
            raise RecordValidationError(f"record {index}: {error}") from error
        if record["id"] in seen:
            raise RecordValidationError(
                f"record {index}: duplicate id {record['id']!r}"
            )
        seen.add(record["id"])
        count += 1
    return count


def iter_jsonl(path: Path) -> Iterable[dict[str, Any]]:
    with path.open(encoding="utf-8") as file:
        for line_number, line in enumerate(file, 1):
            if not line.strip():
                continue
            try:
                value = json.loads(line)
            except json.JSONDecodeError as error:
                raise RecordValidationError(
                    f"{path}:{line_number}: invalid JSON: {error.msg}"
                ) from error
            if not isinstance(value, dict):
                raise RecordValidationError(
                    f"{path}:{line_number}: JSONL value must be an object"
                )
            yield value


def validate_jsonl(path: Path) -> int:
    return validate_records(iter_jsonl(path))


def validate_source_registry(registry: Mapping[str, Any]) -> None:
    if registry.get("schema_version") != "1.0.0":
        raise ValueError("registry schema_version must be 1.0.0")
    sources = registry.get("sources")
    if not isinstance(sources, list):
        raise ValueError("registry sources must be an array")
    seen: set[str] = set()
    for source in sources:
        if not isinstance(source, dict):
            raise ValueError("each registry source must be an object")
        for field in (
            "source_id",
            "name",
            "source_family",
            "endpoint_url",
            "access",
            "rate_limit",
        ):
            if field not in source:
                raise ValueError(f"source is missing {field}")
        source_id = source["source_id"]
        if (
            not isinstance(source_id, str)
            or not re.fullmatch(r"source:[a-z0-9][a-z0-9_-]*", source_id)
        ):
            raise ValueError(f"invalid source_id: {source_id!r}")
        if source_id in seen:
            raise ValueError(f"duplicate source_id: {source_id}")
        seen.add(source_id)
        if source["source_family"] not in SOURCE_FAMILIES:
            raise ValueError(
                f"unsupported source_family: {source['source_family']!r}"
            )
        if not isinstance(source["name"], str) or not source["name"].strip():
            raise ValueError(f"invalid source name for {source_id}")
        if not _is_http_url(source["endpoint_url"]):
            raise ValueError(f"invalid endpoint_url for {source_id}")
        resource_types = source.get("resource_types")
        if (
            not isinstance(resource_types, list)
            or not resource_types
            or any(item not in RECORD_TYPES for item in resource_types)
        ):
            raise ValueError(f"invalid resource_types for {source_id}")
        if len(resource_types) != len(set(resource_types)):
            raise ValueError(f"duplicate resource_types for {source_id}")
        if "allowed_hosts" in source and (
            not isinstance(source["allowed_hosts"], list)
            or not source["allowed_hosts"]
            or any(
                not isinstance(host, str) or not host.strip()
                for host in source["allowed_hosts"]
            )
        ):
            raise ValueError(f"invalid allowed_hosts for {source_id}")
        if "defaults" in source and not isinstance(source["defaults"], dict):
            raise ValueError(f"invalid defaults for {source_id}")
        access = source["access"]
        if not isinstance(access, dict):
            raise ValueError(f"invalid access definition for {source_id}")
        for field in (
            "review_status",
            "terms_url",
            "robots_url",
            "license",
            "reuse_notes",
        ):
            if field not in access:
                raise ValueError(f"access for {source_id} is missing {field}")
        if access["review_status"] not in {
            "reviewed",
            "conditional",
            "blocked",
        }:
            raise ValueError(f"invalid review_status for {source_id}")
        for field in ("terms_url", "robots_url"):
            if not _is_http_url(access[field]):
                raise ValueError(f"invalid {field} for {source_id}")
        for field in ("license", "reuse_notes"):
            if not isinstance(access[field], str) or not access[field].strip():
                raise ValueError(f"invalid {field} for {source_id}")
        if not isinstance(source["rate_limit"], dict):
            raise ValueError(f"invalid rate limit for {source_id}")
        rate = source["rate_limit"].get("requests_per_second")
        if not isinstance(rate, (int, float)) or rate <= 0:
            raise ValueError(f"invalid rate limit for {source_id}")


def load_registry(path: Path) -> dict[str, Any]:
    with path.open(encoding="utf-8") as file:
        registry = json.load(file)
    validate_source_registry(registry)
    return registry


def select_source(
    registry: Mapping[str, Any], source_id: str
) -> dict[str, Any]:
    for source in registry["sources"]:
        if source["source_id"] == source_id:
            return source
    raise KeyError(f"unknown source_id: {source_id}")
