"""Lossless adapter for the reference deity_excerpts.jsonl format."""

from datetime import datetime
import json
from typing import Any, Iterable, Mapping

from religious_mythology_resource_hunter.adapters import SourceAdapter
from religious_mythology_resource_hunter.catalog import Entity


class LegacyJsonlAdapter(SourceAdapter):
    source_family = "legacy_jsonl"

    def parse_sample(
        self,
        payload: bytes,
        *,
        source: Mapping[str, Any],
        entities: Iterable[Entity],
        retrieved_at: datetime,
    ) -> list[dict[str, Any]]:
        del source, entities, retrieved_at
        records = []
        for line_number, line in enumerate(
            payload.decode("utf-8").splitlines(), 1
        ):
            if not line.strip():
                continue
            value = json.loads(line)
            if not isinstance(value, dict):
                raise ValueError(
                    f"legacy JSONL line {line_number} is not an object"
                )
            records.append(value)
        return records

