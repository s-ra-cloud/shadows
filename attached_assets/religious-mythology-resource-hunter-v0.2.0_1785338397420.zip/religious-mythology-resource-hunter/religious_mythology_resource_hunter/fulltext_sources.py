"""Validation and access checks for full-text source definitions."""

import json
from pathlib import Path
from typing import Any, Mapping
from urllib.parse import urlparse


def validate_fulltext_registry(registry: Mapping[str, Any]) -> None:
    if registry.get("schema_version") != "1.0.0":
        raise ValueError("full-text registry schema_version must be 1.0.0")
    sources = registry.get("sources")
    if not isinstance(sources, list):
        raise ValueError("full-text registry sources must be an array")
    seen = set()
    for source in sources:
        if not isinstance(source, dict):
            raise ValueError("full-text source must be an object")
        required = {
            "source_id",
            "name",
            "local_only",
            "allowed_hosts",
            "automated_download_allowed",
            "terms_url",
            "robots_mode",
            "requests_per_second",
            "rights_notes",
        }
        missing = required - set(source)
        if missing:
            raise ValueError(
                f"full-text source is missing: {sorted(missing)}"
            )
        source_id = source["source_id"]
        if not isinstance(source_id, str) or not source_id.startswith(
            "source:"
        ):
            raise ValueError(f"invalid full-text source_id: {source_id!r}")
        if source_id in seen:
            raise ValueError(f"duplicate full-text source_id: {source_id}")
        seen.add(source_id)
        if not isinstance(source["local_only"], bool):
            raise ValueError(f"invalid local_only for {source_id}")
        if not isinstance(source["automated_download_allowed"], bool):
            raise ValueError(
                f"invalid automated_download_allowed for {source_id}"
            )
        if (
            not isinstance(source["allowed_hosts"], list)
            or any(
                not isinstance(host, str) or not host
                for host in source["allowed_hosts"]
            )
        ):
            raise ValueError(f"invalid allowed_hosts for {source_id}")
        prefixes = source.get("allowed_path_prefixes", [])
        if not isinstance(prefixes, list) or any(
            not isinstance(prefix, str) or not prefix.startswith("/")
            for prefix in prefixes
        ):
            raise ValueError(f"invalid allowed_path_prefixes for {source_id}")
        if source["robots_mode"] not in {
            "not_applicable",
            "target_origin",
        }:
            raise ValueError(f"invalid robots_mode for {source_id}")
        rate = source["requests_per_second"]
        if not isinstance(rate, (int, float)) or rate <= 0:
            raise ValueError(f"invalid requests_per_second for {source_id}")


def load_fulltext_registry(path: Path) -> dict[str, Any]:
    with path.open(encoding="utf-8") as file:
        registry = json.load(file)
    if not isinstance(registry, dict):
        raise ValueError("full-text registry must be an object")
    validate_fulltext_registry(registry)
    return registry


def select_fulltext_source(
    registry: Mapping[str, Any], source_id: str
) -> dict[str, Any]:
    for source in registry["sources"]:
        if source["source_id"] == source_id:
            return source
    raise KeyError(f"unknown full-text source_id: {source_id}")


def validate_candidate_access(
    candidate: Mapping[str, Any], source: Mapping[str, Any]
) -> None:
    if candidate["source_id"] != source["source_id"]:
        raise ValueError("candidate/source source_id mismatch")
    access = candidate["access"]
    if not access["download_allowed"]:
        raise PermissionError("candidate metadata does not authorize download")
    if access.get("requires_auth", False):
        raise PermissionError(
            "authenticated or access-controlled retrieval is not supported"
        )
    local_path = candidate.get("local_path")
    if local_path:
        if not source["local_only"]:
            raise ValueError(
                "local_path candidate must use a local-only source"
            )
        return
    if source["local_only"]:
        raise ValueError("local-only source cannot retrieve a remote URL")
    if not source["automated_download_allowed"]:
        raise PermissionError(
            "source registry does not authorize automated download"
        )
    validate_remote_url(str(candidate["text_url"]), source)


def validate_remote_url(url: str, source: Mapping[str, Any]) -> None:
    parsed = urlparse(url)
    if parsed.scheme != "https" or not parsed.netloc:
        raise PermissionError("remote full-text URL must use HTTPS")
    target_host = (parsed.hostname or "").casefold()
    allowed_hosts = [
        str(host).casefold() for host in source["allowed_hosts"]
    ]
    if not any(
        target_host == host or target_host.endswith("." + host)
        for host in allowed_hosts
    ):
        raise PermissionError(
            f"target host is not allowed for {source['source_id']}"
        )
    prefixes = source.get("allowed_path_prefixes", [])
    if prefixes and not any(
        parsed.path.startswith(prefix) for prefix in prefixes
    ):
        raise PermissionError(
            f"target path is not allowed for {source['source_id']}"
        )
