"""Language and rights prioritization for complete text editions."""

from datetime import datetime
from typing import Any, Iterable, Mapping

from religious_mythology_resource_hunter.rights import assess_rights


def _format_rank(candidate: Mapping[str, Any], policy: Mapping[str, Any]) -> int:
    try:
        return list(policy["preferred_formats"]).index(candidate["format"])
    except ValueError:
        return len(policy["preferred_formats"])


def _candidate_sort_key(
    plan: Mapping[str, Any], policy: Mapping[str, Any]
) -> tuple[int, int, str]:
    assessment = plan["rights_assessment"]
    rights_rank = {
        "public_domain": 0,
        "open_license": 1,
        "public_domain_likely": 2,
        "public_domain_jurisdictional": 3,
        "restricted_license": 4,
        "copyrighted": 5,
        "conflicting": 6,
        "unknown": 7,
    }.get(assessment["status"], 8)
    candidate = plan["candidate"]
    return (
        rights_rank,
        _format_rank(candidate, policy),
        str(candidate["edition_id"]),
    )


def _mark(
    plan: dict[str, Any], reason: str, rank: int
) -> None:
    current = plan["selection"]
    if not current["selected"] or rank < current["rank"]:
        plan["selection"] = {
            "selected": True,
            "reason": reason,
            "rank": rank,
        }


def plan_candidates(
    candidates: Iterable[dict[str, Any]],
    policy: Mapping[str, Any],
    *,
    assessed_at: datetime,
) -> list[dict[str, Any]]:
    """Choose English + original, then an AI-translatable open fallback."""
    plans = [
        {
            "candidate": candidate,
            "rights_assessment": assess_rights(
                candidate, policy, assessed_at=assessed_at
            ),
            "selection": {
                "selected": False,
                "reason": "not_selected",
                "rank": 999,
            },
        }
        for candidate in candidates
    ]
    groups: dict[str, list[dict[str, Any]]] = {}
    for plan in plans:
        groups.setdefault(plan["candidate"]["work_id"], []).append(plan)

    ai_languages = list(policy["ai_translatable_languages"])
    for work_plans in groups.values():
        available = [
            plan
            for plan in work_plans
            if plan["candidate"]["access"]["download_allowed"]
            and not plan["candidate"]["access"].get("requires_auth", False)
        ]
        open_plans = [
            plan
            for plan in available
            if plan["rights_assessment"]["publication_allowed"]
        ]
        open_english = [
            plan
            for plan in open_plans
            if plan["candidate"]["language"].casefold() == "en"
        ]
        open_original = [
            plan
            for plan in open_plans
            if plan["candidate"]["language_role"] == "original"
        ]
        if open_english:
            best = min(
                open_english,
                key=lambda item: _candidate_sort_key(item, policy),
            )
            _mark(best, "preferred_open_english", 1)
        if open_original:
            best = min(
                open_original,
                key=lambda item: _candidate_sort_key(item, policy),
            )
            _mark(best, "preferred_open_original", 2)

        if not open_english:
            fallback = [
                plan
                for plan in open_plans
                if plan["candidate"]["language"] in ai_languages
                and plan["candidate"]["language_role"] != "original"
            ]
            if not fallback:
                fallback = [
                    plan
                    for plan in open_plans
                    if plan["candidate"]["language"] in ai_languages
                ]
            if fallback:
                def fallback_key(item: Mapping[str, Any]) -> tuple[int, int, int, str]:
                    language = item["candidate"]["language"]
                    return (
                        ai_languages.index(language),
                        *_candidate_sort_key(item, policy),
                    )

                best = min(fallback, key=fallback_key)
                _mark(best, "fallback_open_ai_translatable", 3)

        locked = [
            plan
            for plan in available
            if not plan["rights_assessment"]["publication_allowed"]
        ]
        if not open_english:
            locked_english = [
                plan
                for plan in locked
                if plan["candidate"]["language"].casefold() == "en"
            ]
            if locked_english:
                best = min(
                    locked_english,
                    key=lambda item: _candidate_sort_key(item, policy),
                )
                _mark(best, "locked_english_reference", 10)
        if not open_original:
            locked_original = [
                plan
                for plan in locked
                if plan["candidate"]["language_role"] == "original"
            ]
            if locked_original:
                best = min(
                    locked_original,
                    key=lambda item: _candidate_sort_key(item, policy),
                )
                _mark(best, "locked_original_reference", 11)
        if not any(plan["selection"]["selected"] for plan in work_plans):
            if available:
                best = min(
                    available,
                    key=lambda item: _candidate_sort_key(item, policy),
                )
                _mark(best, "only_authorized_candidate", 20)
    return plans
