# AGENTS.md

## Mission

Build a rights-aware full-text hunter for religious and mythological source
corpora. The hunter discovers or receives edition candidates, evaluates
edition-specific rights evidence, prioritizes languages, and stores complete
source bytes unchanged.

Divinity/entity extraction is a separate downstream stage. Do not make excerpt
generation, alias matching, graph building, or interpretation part of the
full-text download boundary.

## Current phase

Allowed:

- full-text source and edition registries;
- versioned candidate, corpus, rights, lock, and policy schemas;
- conservative rights assessment with traceable evidence;
- original-language and translation-edition metadata;
- fixture-scale or operator-supplied batch download;
- robots, allowed-host/path, rate, terms, and access enforcement;
- public/locked storage partitions, checksums, permissions, and lock markers;
- immutable local fixtures and deterministic tests;
- downstream extraction compatibility kept explicitly separate.

Not yet allowed:

- bypassing authentication, paywalls, robots rules, source terms, or technical
  controls;
- assuming that public web access means download or publication permission;
- unlocking a text solely from a title, ancient authorship, or rough date;
- treating an original work's status as the status of a modern translation;
- unattended crawling without a reviewed source discovery contract;
- automatic online publication;
- deleting or weakening a lock without new reviewed rights evidence;
- cloud deployment, secrets, or production databases.

## Full-text invariants

1. Store the entire downloaded payload byte-for-byte; never replace it with
   deity excerpts.
2. One candidate and one rights decision correspond to one specific edition or
   translation.
3. Download authorization and publication authorization are distinct.
4. Unknown, copyrighted, restricted, U.S.-only in a France-targeted policy,
   and heuristic-only editions remain locked.
5. Locked files live under `locked/`, use `0600` permissions, and have a
   `.LOCK.json` marker.
6. Publishable files live under `public/` only when explicit evidence covers
   the configured jurisdiction or supplies a compatible worldwide open
   licence.
7. Preserve source URL/path, metadata URL, statement, licence, territories,
   assessment basis/time, obligations, checksum, content type, and byte count.
8. Refuse to overwrite an existing full-text file whose checksum differs.
9. Prefer cleared English plus the cleared original. If cleared English is
   unavailable, prefer a cleared configured AI-translatable edition.
10. AI translation is never performed inside the hunter and never changes a
    source file.
11. Respect copyright, contractual, cultural, sacred, community, privacy,
    moral-rights, and traditional-cultural-expression restrictions.
12. Rights assessment is a documented risk-control process, not legal advice.

## Rights rules

- Prefer explicit standardized evidence over date inference.
- Treat CC0/Public Domain Mark and territory-covered public-domain statements
  as publishable.
- Treat CC BY and CC BY-SA as publishable while retaining obligations.
- Keep NC and ND variants locked under the default publication/translation
  policy.
- Keep RightsStatements.org `InC-*`, restricted `NoC-*`, unknown, and
  jurisdiction-mismatched statements locked.
- Date calculations produce `public_domain_likely` only. They stay locked
  unless a human changes the policy after reviewing special cases.
- Inspect embedded notices after download; a restrictive embedded notice may
  move a file into the locked partition.

## Source acceptance

A remote source is enabled only after:

- its automated-access documentation, terms, robots behavior, allowed hosts
  and paths, and conservative rate are recorded;
- per-edition rights evidence can be retained;
- at least ten complete immutable samples are checksum-verified;
- original and translation editions remain distinguishable;
- retry and pagination behavior are tested;
- a human confirms that collection is legally and culturally appropriate.

## Downstream extraction

Existing TEI, IIIF, OAI-DC, MediaWiki, plain-text, and legacy JSONL parsers may
remain for later extraction. Their output must not replace the corpus manifest
or full-text files. New hunter work should target `plan`, `download`,
`verify-corpus`, rights assessment, or full-text source discovery.

